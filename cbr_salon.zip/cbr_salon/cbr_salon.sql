-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jul 2020 pada 09.35
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cbr_salon`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `appointment`
--

CREATE TABLE `appointment` (
  `id_appointment` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `pesan` text NOT NULL,
  `status` enum('Menunggu','Disetujui','Ditolak') NOT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `appointment`
--

INSERT INTO `appointment` (`id_appointment`, `id_member`, `tanggal`, `jam`, `pesan`, `status`, `keterangan`) VALUES
(1, 1, '2020-05-18', '09:00:00', 'Mau konsultasi', 'Disetujui', 'Oke'),
(5, 2, '2020-05-21', '16:00:00', 'Mau konsultasi', 'Ditolak', 'Ada acara ke luar kota'),
(14, 1, '2020-05-22', '07:50:00', 'Okay test', 'Disetujui', 'Oke, ditunggu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `chat`
--

CREATE TABLE `chat` (
  `id_chat` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `judul` varchar(100) NOT NULL,
  `terakhir_dibalas` enum('Member','Admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `chat`
--

INSERT INTO `chat` (`id_chat`, `id_member`, `tanggal`, `judul`, `terakhir_dibalas`) VALUES
(1, 1, '2020-05-17', 'Konsultasi penyakit gatal', 'Member'),
(3, 2, '2020-05-17', 'Tips menjaga kecantikan', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `chat_detail`
--

CREATE TABLE `chat_detail` (
  `id_chat_detail` int(11) NOT NULL,
  `id_chat` int(11) NOT NULL,
  `waktu` datetime NOT NULL,
  `pesan` text NOT NULL,
  `oleh` enum('Member','Admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `chat_detail`
--

INSERT INTO `chat_detail` (`id_chat_detail`, `id_chat`, `waktu`, `pesan`, `oleh`) VALUES
(1, 1, '2020-05-17 11:55:48', 'Silahkan, sebutkan gejala-gejala yang dirasakan', 'Admin'),
(2, 1, '2020-05-17 11:57:02', 'Gejala yang saya rasakan yaitu pusing dan meriang', 'Member'),
(3, 1, '2020-05-17 13:37:56', 'Apakah sebelumnya punya riwayat penyakit berat?', 'Admin'),
(4, 1, '2020-05-17 14:33:59', 'Tidak ada dok', 'Member'),
(5, 3, '2020-05-17 14:37:44', 'Halo dok, saya mau minta tips buat menjaga kecantikan', 'Member'),
(6, 3, '2020-05-17 14:38:28', 'Tips nya jangan suka begadang ya', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` int(11) NOT NULL,
  `kode_gejala` varchar(10) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL,
  `bobot` float NOT NULL,
  `id_kategori` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `kode_gejala`, `nama_gejala`, `bobot`, `id_kategori`) VALUES
(21, 'G001', 'Rambut Berketombe', 10, 2),
(22, 'G002', 'Kulit Kepala Gatal', 10, 2),
(23, 'G003', 'Rambut Berminyak dan Kering', 10, 2),
(24, 'G004', 'Rambut Kering dan Rusak', 15, 1),
(25, 'G005', 'Rambut Bercabang dan Pecah', 15, 1),
(26, 'G006', 'Rambut Lurus dan Kaku', 10, 2),
(27, 'G007', 'Rambut Keriting Susah Di Atur', 10, 2),
(28, 'G008', 'Rambut Kasar / Bercabang', 15, 1),
(29, 'G009', 'Rambut Beruban', 10, 2),
(30, 'G010', 'Warna Rambut Level Tinggi', 15, 1),
(31, 'G011', 'Warna Rambut Normal', 10, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `hasil`
--

CREATE TABLE `hasil` (
  `id_hasil` int(11) NOT NULL,
  `id_konsultasi` int(11) NOT NULL,
  `id_penyakit` int(11) NOT NULL,
  `nilai_kedekatan` float NOT NULL,
  `id_kasus` int(11) NOT NULL,
  `bayar` tinyint(4) NOT NULL,
  `bukti_transfer` text NOT NULL,
  `acc` tinyint(4) NOT NULL,
  `notif` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `hasil`
--

INSERT INTO `hasil` (`id_hasil`, `id_konsultasi`, `id_penyakit`, `nilai_kedekatan`, `id_kasus`, `bayar`, `bukti_transfer`, `acc`, `notif`) VALUES
(10, 5, 38, 0.4, 15, 0, '', 0, 0),
(11, 6, 38, 1, 15, 0, '', 0, 0),
(12, 7, 38, 0.666667, 15, 0, '', 0, 0),
(13, 8, 38, 0, 15, 0, '', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kasus`
--

CREATE TABLE `kasus` (
  `id_kasus` int(11) NOT NULL,
  `nama_kasus` varchar(50) NOT NULL,
  `id_penyakit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kasus`
--

INSERT INTO `kasus` (`id_kasus`, `nama_kasus`, `id_penyakit`) VALUES
(15, 'Kasus 1', 38),
(16, 'Kasus 2', 39),
(17, 'Kasus 3', 40),
(18, 'Kasus 4', 41),
(19, 'Kasus 5', 42),
(20, 'Kasus 6', 43),
(21, 'Kasus 7', 44),
(22, 'Kasus 8', 45),
(23, 'Kasus 9', 46),
(24, 'Kasus 10', 47);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kasus_gejala`
--

CREATE TABLE `kasus_gejala` (
  `id_kasus_gejala` int(11) NOT NULL,
  `id_kasus` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL,
  `id_nilai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kasus_gejala`
--

INSERT INTO `kasus_gejala` (`id_kasus_gejala`, `id_kasus`, `id_gejala`, `id_nilai`) VALUES
(67, 15, 21, 101),
(68, 15, 22, 103),
(69, 15, 23, 106),
(71, 15, 24, 111),
(72, 15, 25, 113),
(73, 15, 26, 115),
(74, 15, 27, 117),
(75, 15, 28, 125),
(76, 15, 29, 123),
(77, 15, 30, 119),
(78, 15, 31, 121),
(79, 16, 21, 102),
(80, 16, 22, 104),
(81, 16, 23, 105),
(82, 16, 24, 111),
(83, 16, 25, 113),
(84, 16, 26, 115),
(85, 16, 27, 117),
(86, 16, 28, 125),
(87, 16, 29, 123),
(88, 16, 30, 119),
(89, 16, 31, 121),
(90, 17, 21, 102),
(91, 17, 22, 104),
(92, 17, 23, 106),
(93, 17, 24, 110),
(94, 17, 25, 113),
(95, 17, 26, 115),
(96, 17, 27, 117),
(97, 17, 28, 125),
(98, 17, 29, 123),
(99, 17, 30, 119),
(100, 17, 31, 121),
(101, 18, 21, 102),
(102, 18, 22, 104),
(103, 18, 23, 106),
(104, 18, 24, 111),
(105, 18, 25, 112),
(106, 18, 26, 115),
(107, 18, 27, 117),
(108, 18, 28, 125),
(109, 18, 29, 123),
(110, 18, 30, 119),
(111, 18, 31, 121),
(112, 19, 21, 102),
(113, 19, 22, 104),
(114, 19, 23, 106),
(115, 19, 24, 111),
(116, 19, 25, 113),
(117, 19, 26, 114),
(118, 19, 27, 117),
(119, 19, 28, 125),
(120, 19, 29, 123),
(121, 19, 30, 119),
(122, 19, 31, 121),
(123, 20, 21, 102),
(124, 20, 22, 104),
(125, 20, 23, 106),
(126, 20, 24, 111),
(127, 20, 25, 113),
(128, 20, 26, 115),
(129, 20, 27, 116),
(130, 20, 28, 125),
(131, 20, 29, 123),
(132, 20, 30, 119),
(133, 20, 31, 121),
(134, 21, 21, 102),
(135, 21, 22, 104),
(136, 21, 23, 106),
(137, 21, 24, 110),
(138, 21, 25, 113),
(139, 21, 26, 114),
(140, 21, 27, 117),
(141, 21, 28, 124),
(142, 21, 29, 123),
(143, 21, 30, 119),
(144, 21, 31, 121),
(145, 22, 21, 102),
(146, 22, 22, 104),
(147, 22, 23, 106),
(148, 22, 24, 111),
(149, 22, 25, 113),
(150, 22, 26, 115),
(151, 22, 27, 117),
(152, 22, 28, 125),
(153, 22, 29, 122),
(154, 22, 30, 119),
(155, 22, 31, 120),
(156, 23, 21, 102),
(157, 23, 22, 104),
(158, 23, 23, 106),
(159, 23, 24, 111),
(160, 23, 25, 113),
(161, 23, 26, 115),
(162, 23, 27, 117),
(163, 23, 28, 125),
(164, 23, 29, 122),
(165, 23, 30, 119),
(166, 23, 31, 121),
(167, 24, 21, 102),
(168, 24, 22, 104),
(169, 24, 23, 106),
(170, 24, 24, 111),
(171, 24, 25, 113),
(172, 24, 26, 115),
(173, 24, 27, 117),
(174, 24, 28, 125),
(175, 24, 29, 123),
(176, 24, 30, 118),
(177, 24, 31, 121);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Gejala Berat'),
(2, 'Gejala Ringan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kedekatan`
--

CREATE TABLE `kedekatan` (
  `id_kedekatan` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL,
  `id_nilai_1` int(11) NOT NULL,
  `id_nilai_2` int(11) NOT NULL,
  `nilai_kedekatan` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kedekatan`
--

INSERT INTO `kedekatan` (`id_kedekatan`, `id_gejala`, `id_nilai_1`, `id_nilai_2`, `nilai_kedekatan`) VALUES
(690, 21, 102, 102, 0),
(691, 21, 102, 101, 0),
(692, 21, 101, 102, 0),
(693, 21, 101, 101, 1),
(694, 22, 104, 104, 0),
(695, 22, 104, 103, 0),
(696, 22, 103, 104, 0),
(697, 22, 103, 103, 1),
(698, 23, 106, 106, 0),
(699, 23, 106, 105, 0),
(700, 23, 105, 106, 0),
(701, 23, 105, 105, 1),
(706, 24, 111, 111, 0),
(707, 24, 111, 110, 0),
(708, 24, 110, 111, 0),
(709, 24, 110, 110, 1),
(710, 25, 113, 113, 0),
(711, 25, 113, 112, 0),
(712, 25, 112, 113, 0),
(713, 25, 112, 112, 1),
(714, 26, 115, 115, 0),
(715, 26, 115, 114, 0),
(716, 26, 114, 115, 0),
(717, 26, 114, 114, 1),
(718, 27, 117, 117, 0),
(719, 27, 117, 116, 0),
(720, 27, 116, 117, 0),
(721, 27, 116, 116, 1),
(722, 30, 119, 119, 0),
(723, 30, 119, 118, 0),
(724, 30, 118, 119, 0),
(725, 30, 118, 118, 1),
(726, 31, 121, 121, 0),
(727, 31, 121, 120, 0),
(728, 31, 120, 121, 0),
(729, 31, 120, 120, 1),
(730, 29, 123, 123, 0),
(731, 29, 123, 122, 0),
(732, 29, 122, 123, 0),
(733, 29, 122, 122, 1),
(734, 28, 125, 125, 0),
(735, 28, 125, 124, 0),
(736, 28, 124, 125, 0),
(737, 28, 124, 124, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `konsultasi`
--

CREATE TABLE `konsultasi` (
  `id_konsultasi` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `id_member` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `konsultasi`
--

INSERT INTO `konsultasi` (`id_konsultasi`, `tanggal`, `id_member`) VALUES
(1, '2020-05-17', NULL),
(2, '2020-05-17', NULL),
(3, '2020-05-17', 1),
(4, '2020-05-17', 2),
(5, '2020-05-17', NULL),
(6, '2020-07-09', NULL),
(7, '2020-07-09', NULL),
(8, '2020-07-09', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `konsultasi_gejala`
--

CREATE TABLE `konsultasi_gejala` (
  `id_konsultasi_gejala` int(11) NOT NULL,
  `id_konsultasi` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL,
  `id_nilai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `konsultasi_gejala`
--

INSERT INTO `konsultasi_gejala` (`id_konsultasi_gejala`, `id_konsultasi`, `id_gejala`, `id_nilai`) VALUES
(19, 6, 21, 101),
(20, 6, 22, 103),
(21, 6, 23, 106),
(23, 7, 21, 102),
(24, 7, 22, 104),
(25, 7, 23, 106),
(27, 8, 21, 102),
(28, 8, 22, 104),
(29, 8, 23, 106),
(30, 8, 24, 111);

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `id_member` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `id_pengguna` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`id_member`, `nama`, `alamat`, `jenis_kelamin`, `no_hp`, `id_pengguna`) VALUES
(1, 'Jamal', 'Jl. Merdeka No. 22', 'Laki-Laki', '089675654543', 3),
(2, 'Maman', 'Jl. Jati No. 13', 'Laki-Laki', '085123456789', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai`
--

CREATE TABLE `nilai` (
  `id_nilai` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL,
  `nama_nilai` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nilai`
--

INSERT INTO `nilai` (`id_nilai`, `id_gejala`, `nama_nilai`) VALUES
(101, 21, 'Ya'),
(102, 21, 'Tidak'),
(103, 22, 'Ya'),
(104, 22, 'Tidak'),
(105, 23, 'Ya'),
(106, 23, 'Tidak'),
(110, 24, 'Ya'),
(111, 24, 'Tidak'),
(112, 25, 'Ya'),
(113, 25, 'Tidak'),
(114, 26, 'Ya'),
(115, 26, 'Tidak'),
(116, 27, 'Ya'),
(117, 27, 'Tidak'),
(118, 30, 'Ya'),
(119, 30, 'Tidak'),
(120, 31, 'Ya'),
(121, 31, 'Tidak'),
(122, 29, 'Ya'),
(123, 29, 'Tidak'),
(124, 28, 'Ya'),
(125, 28, 'Tidak');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `akses_level` enum('Admin','Member') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `password`, `akses_level`) VALUES
(1, 'Administrator', 'admin', '$2y$10$dO1ykwZHsa/sZbEB4thS7OuLC3Rsp6v/R7J9..QgcCT0dJuujTLwK', 'Admin'),
(3, 'Jamal', 'jamal', '$2y$10$xYVxwLp5cv/Idpei7d1f..vx5z39mPnv6BZEYrgaBdCCFFp/kc3p.', 'Member'),
(4, 'Maman', 'maman', '$2y$10$aK8UgZE90b.HXTdpjnaM/OwKCW0bVHFHOz60ZSF6knrxqzeMxigA2', 'Member');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyakit`
--

CREATE TABLE `penyakit` (
  `id_penyakit` int(11) NOT NULL,
  `kode_penyakit` varchar(10) NOT NULL,
  `nama_penyakit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `kode_penyakit`, `nama_penyakit`) VALUES
(38, 'P001', 'Penyakit 1'),
(39, 'P002', 'Penyakit 2'),
(40, 'P003', 'Penyakit 3'),
(41, 'P004', 'Penyakit 4'),
(42, 'P005', 'Penyakit 5'),
(43, 'P006', 'Penyakit 6'),
(44, 'P007', 'Penyakit 7'),
(45, 'P008', 'Penyakit 8'),
(46, 'P009', 'Penyakit 9'),
(47, 'P010', 'Penyakit 10');

-- --------------------------------------------------------

--
-- Struktur dari tabel `solusi`
--

CREATE TABLE `solusi` (
  `id_solusi` int(11) NOT NULL,
  `id_penyakit` int(11) NOT NULL,
  `solusi_penyakit` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `solusi`
--

INSERT INTO `solusi` (`id_solusi`, `id_penyakit`, `solusi_penyakit`) VALUES
(5, 38, 'Hair Spa Makarizo Mint Sorbet'),
(6, 39, 'Hair Spa Loreal Nourishing'),
(7, 40, 'Go Street Hair Masker'),
(8, 41, 'Creambath'),
(9, 42, 'Digital Perm'),
(10, 43, 'Smoothing'),
(11, 44, 'Coco Keratin'),
(12, 45, 'Hair Coloring'),
(13, 46, 'Hair Manicure'),
(14, 47, 'Bleaching');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id_appointment`) USING BTREE,
  ADD KEY `id_member` (`id_member`);

--
-- Indeks untuk tabel `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id_chat`),
  ADD KEY `id_member` (`id_member`);

--
-- Indeks untuk tabel `chat_detail`
--
ALTER TABLE `chat_detail`
  ADD PRIMARY KEY (`id_chat_detail`),
  ADD KEY `id_chat` (`id_chat`);

--
-- Indeks untuk tabel `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id_hasil`),
  ADD KEY `id_konsultasi` (`id_konsultasi`) USING BTREE,
  ADD KEY `id_penyakit` (`id_penyakit`) USING BTREE,
  ADD KEY `id_kasus` (`id_kasus`) USING BTREE;

--
-- Indeks untuk tabel `kasus`
--
ALTER TABLE `kasus`
  ADD PRIMARY KEY (`id_kasus`) USING BTREE,
  ADD KEY `id_penyakit` (`id_penyakit`) USING BTREE;

--
-- Indeks untuk tabel `kasus_gejala`
--
ALTER TABLE `kasus_gejala`
  ADD PRIMARY KEY (`id_kasus_gejala`) USING BTREE,
  ADD KEY `id_nilai` (`id_nilai`),
  ADD KEY `id_gejala` (`id_gejala`) USING BTREE,
  ADD KEY `id_kasus` (`id_kasus`) USING BTREE;

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `kedekatan`
--
ALTER TABLE `kedekatan`
  ADD PRIMARY KEY (`id_kedekatan`),
  ADD KEY `id_nilai_1` (`id_nilai_1`) USING BTREE,
  ADD KEY `id_nilai_2` (`id_nilai_2`) USING BTREE,
  ADD KEY `id_gejala` (`id_gejala`) USING BTREE;

--
-- Indeks untuk tabel `konsultasi`
--
ALTER TABLE `konsultasi`
  ADD PRIMARY KEY (`id_konsultasi`),
  ADD KEY `id_member` (`id_member`);

--
-- Indeks untuk tabel `konsultasi_gejala`
--
ALTER TABLE `konsultasi_gejala`
  ADD PRIMARY KEY (`id_konsultasi_gejala`),
  ADD KEY `id_nilai` (`id_nilai`),
  ADD KEY `id_konsultasi` (`id_konsultasi`) USING BTREE,
  ADD KEY `id_gejala` (`id_gejala`) USING BTREE;

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id_member`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indeks untuk tabel `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id_nilai`),
  ADD KEY `id_gejala` (`id_gejala`) USING BTREE;

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indeks untuk tabel `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id_penyakit`);

--
-- Indeks untuk tabel `solusi`
--
ALTER TABLE `solusi`
  ADD PRIMARY KEY (`id_solusi`),
  ADD KEY `id_penyakit` (`id_penyakit`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id_appointment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `chat`
--
ALTER TABLE `chat`
  MODIFY `id_chat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `chat_detail`
--
ALTER TABLE `chat_detail`
  MODIFY `id_chat_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT untuk tabel `hasil`
--
ALTER TABLE `hasil`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `kasus`
--
ALTER TABLE `kasus`
  MODIFY `id_kasus` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `kasus_gejala`
--
ALTER TABLE `kasus_gejala`
  MODIFY `id_kasus_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kedekatan`
--
ALTER TABLE `kedekatan`
  MODIFY `id_kedekatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=738;

--
-- AUTO_INCREMENT untuk tabel `konsultasi`
--
ALTER TABLE `konsultasi`
  MODIFY `id_konsultasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `konsultasi_gejala`
--
ALTER TABLE `konsultasi_gejala`
  MODIFY `id_konsultasi_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `penyakit`
--
ALTER TABLE `penyakit`
  MODIFY `id_penyakit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT untuk tabel `solusi`
--
ALTER TABLE `solusi`
  MODIFY `id_solusi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `member` (`id_member`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `member` (`id_member`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `chat_detail`
--
ALTER TABLE `chat_detail`
  ADD CONSTRAINT `chat_detail_ibfk_1` FOREIGN KEY (`id_chat`) REFERENCES `chat` (`id_chat`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `gejala`
--
ALTER TABLE `gejala`
  ADD CONSTRAINT `gejala_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `hasil`
--
ALTER TABLE `hasil`
  ADD CONSTRAINT `hasil_ibfk_1` FOREIGN KEY (`id_konsultasi`) REFERENCES `konsultasi` (`id_konsultasi`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `hasil_ibfk_2` FOREIGN KEY (`id_kasus`) REFERENCES `kasus` (`id_kasus`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `hasil_ibfk_3` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `kasus`
--
ALTER TABLE `kasus`
  ADD CONSTRAINT `kasus_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `kasus_gejala`
--
ALTER TABLE `kasus_gejala`
  ADD CONSTRAINT `kasus_gejala_ibfk_1` FOREIGN KEY (`id_kasus`) REFERENCES `kasus` (`id_kasus`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `kasus_gejala_ibfk_2` FOREIGN KEY (`id_nilai`) REFERENCES `nilai` (`id_nilai`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `kasus_gejala_ibfk_3` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `kedekatan`
--
ALTER TABLE `kedekatan`
  ADD CONSTRAINT `kedekatan_ibfk_1` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `kedekatan_ibfk_2` FOREIGN KEY (`id_nilai_1`) REFERENCES `nilai` (`id_nilai`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `kedekatan_ibfk_3` FOREIGN KEY (`id_nilai_2`) REFERENCES `nilai` (`id_nilai`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `konsultasi`
--
ALTER TABLE `konsultasi`
  ADD CONSTRAINT `konsultasi_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `member` (`id_member`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `konsultasi_gejala`
--
ALTER TABLE `konsultasi_gejala`
  ADD CONSTRAINT `konsultasi_gejala_ibfk_1` FOREIGN KEY (`id_konsultasi`) REFERENCES `konsultasi` (`id_konsultasi`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `konsultasi_gejala_ibfk_2` FOREIGN KEY (`id_nilai`) REFERENCES `nilai` (`id_nilai`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `konsultasi_gejala_ibfk_3` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `member`
--
ALTER TABLE `member`
  ADD CONSTRAINT `member_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `nilai`
--
ALTER TABLE `nilai`
  ADD CONSTRAINT `nilai_ibfk_1` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `solusi`
--
ALTER TABLE `solusi`
  ADD CONSTRAINT `solusi_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
