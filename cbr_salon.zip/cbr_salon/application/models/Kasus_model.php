<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kasus_model extends CI_Model
{
    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_kasus,
                nama_kasus,
                nama_penyakit
            FROM
                `kasus`
            LEFT JOIN penyakit ON kasus.id_penyakit=penyakit.id_penyakit
            ,(SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama_kasus',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    function get_kasus_gejala($id_kasus, $id_gejala)
    {
        return $this->db
            ->where('id_kasus', $id_kasus)
            ->where('kasus_gejala.id_gejala', $id_gejala)
            ->join('nilai', 'nilai.id_nilai=kasus_gejala.id_nilai', 'left')
            ->get('kasus_gejala');
    }

    public function tambah_kasus($dt)
    {
        $res['result'] = $this->db->insert('kasus', $dt);
        $res['id'] = $this->db->insert_id();
        return $res;
    }

    public function tambah_kasus_gejala($dt)
    {
        return $this->db->insert('kasus_gejala', $dt);
    }

    public function hapus_kasus($id_kasus)
    {
        return $this->db
            ->where('id_kasus', $id_kasus)
            ->delete('kasus');
    }

    public function get_baris($id_kasus)
    {
        return $this->db
            ->where('id_kasus', $id_kasus)
            ->limit(1)
            ->get('kasus');
    }

    public function update_kasus($id_kasus, $dt)
    {
        return $this->db
            ->where('id_kasus', $id_kasus)
            ->update('kasus', $dt);
    }

    public function update_kasus_gejala($id_kasus_gejala, $dt)
    {
        return $this->db
            ->where('id_kasus_gejala', $id_kasus_gejala)
            ->update('kasus_gejala', $dt);
    }

    function get_all()
    {
        return $this->db
            ->order_by('id_kasus', 'asc')
            ->get('kasus');
    }
}

/* End of file Kasus_model.php */
/* Location: ./application/models/Kasus_model.php */
