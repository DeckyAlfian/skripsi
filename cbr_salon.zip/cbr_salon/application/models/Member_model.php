<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Member_model extends CI_Model
{
    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_member,
                nama,
                alamat,
                jenis_kelamin,
                no_hp,
                username
            FROM
                `member`
            LEFT JOIN pengguna ON pengguna.id_pengguna=member.id_pengguna
            ,(SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama',
            2 => 'alamat',
            3 => 'jenis_kelamin',
            4 => 'no_hp',
            5 => 'username',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_member($dt)
    {
        return $this->db->insert('member', $dt);
    }

    public function hapus_member($id_member)
    {
        return $this->db
            ->where('id_member', $id_member)
            ->delete('member');
    }

    public function get_baris($id_member)
    {
        return $this->db
            ->where('id_member', $id_member)
            ->limit(1)
            ->get('member');
    }

    public function get_baris_by_id_pengguna($id_pengguna)
    {
        return $this->db
            ->where('id_pengguna', $id_pengguna)
            ->limit(1)
            ->get('member');
    }

    public function update_member($id_member, $dt)
    {
        return $this->db
            ->where('id_member', $id_member)
            ->update('member', $dt);
    }
}

/* End of file Member_model.php */
/* Location: ./application/models/Member_model.php */
