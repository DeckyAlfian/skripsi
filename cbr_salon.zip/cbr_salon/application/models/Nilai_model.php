<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Nilai_model extends CI_Model
{
    public function fetch_data($id_gejala = '', $column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_nilai,
                nama_nilai
            FROM
                `nilai`, (SELECT @row := 0) r WHERE 1=1
                AND id_gejala = '$id_gejala'
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama_nilai',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_gejala_nilai($dt)
    {
        return $this->db->insert('nilai', $dt);
    }

    public function hapus_gejala_nilai($id_nilai)
    {
        return $this->db
            ->where('id_nilai', $id_nilai)
            ->delete('nilai');
    }

    public function get_baris($id_nilai)
    {
        return $this->db
            ->where('id_nilai', $id_nilai)
            ->limit(1)
            ->get('nilai');
    }

    public function update_gejala_nilai($id_nilai, $dt)
    {
        return $this->db
            ->where('id_nilai', $id_nilai)
            ->update('nilai', $dt);
    }

    function get_all($id_gejala = '')
    {
        return $this->db
            ->where('id_gejala', $id_gejala)
            ->order_by('id_nilai', 'DESC')
            ->get('nilai');
    }

    public function get_nilai_kedekatan($id_gejala, $id_nilai1, $id_nilai2)
    {
        return $this->db
            ->where('id_nilai_1', $id_nilai1)
            ->where('id_nilai_2', $id_nilai2)
            ->where('id_gejala', $id_gejala)
            ->limit(1)
            ->get('kedekatan');
    }

    public function tambah_kedekatan($dt)
    {
        return $this->db->insert('kedekatan', $dt);
    }

    public function update_kedekatan($id_kedekatan, $dt)
    {
        return $this->db
            ->where('id_kedekatan', $id_kedekatan)
            ->update('kedekatan', $dt);
    }
}

/* End of file Nilai_model.php */
/* Location: ./application/models/Nilai_model.php */
