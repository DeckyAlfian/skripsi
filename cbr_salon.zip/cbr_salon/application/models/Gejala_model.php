<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Gejala_model extends CI_Model
{
    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_gejala,
                kode_gejala,
                nama_gejala,
                bobot,
                nama_kategori
            FROM
                `gejala`
            LEFT JOIN kategori ON kategori.id_kategori=gejala.id_kategori
            ,(SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'kode_gejala',
            2 => 'nama_gejala',
            3 => 'bobot',
            4 => 'nama_kategori',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_gejala($dt)
    {
        return $this->db->insert('gejala', $dt);
    }

    public function hapus_gejala($id_gejala)
    {
        return $this->db
            ->where('id_gejala', $id_gejala)
            ->delete('gejala');
    }

    public function get_baris($id_gejala)
    {
        return $this->db
            ->where('id_gejala', $id_gejala)
            ->join('kategori', 'kategori.id_kategori=gejala.id_kategori', 'left')
            ->limit(1)
            ->get('gejala');
    }

    public function update_gejala($id_gejala, $dt)
    {
        return $this->db
            ->where('id_gejala', $id_gejala)
            ->update('gejala', $dt);
    }

    public function cek_kode_gejala($kode_gejala, $kode_gejala_tmp)
    {
        $this->db->where('kode_gejala', $kode_gejala);
        $this->db->where('kode_gejala <>', $kode_gejala_tmp);
        return $this->db->get('gejala');
    }

    function get_all()
    {
        return $this->db
            ->order_by('id_gejala', 'asc')
            ->get('gejala');
    }
}

/* End of file Gejala_model.php */
/* Location: ./application/models/Gejala_model.php */
