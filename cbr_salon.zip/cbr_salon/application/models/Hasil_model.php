<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Hasil_model extends CI_Model
{
    public function tambah_hasil($dt)
    {
        return $this->db->insert('hasil', $dt);
    }

    public function update_hasil($id_hasil, $dt)
    {
        return $this->db
            ->where('id_hasil', $id_hasil)
            ->update('hasil', $dt);
    }

    public function update_notif($dt)
    {
        return $this->db
            ->update('hasil', $dt);
    }

    function get_hasil($id_konsultasi)
    {
        return $this->db
            ->select('member.nama,member.alamat,member.jenis_kelamin,member.no_hp,penyakit.nama_penyakit,solusi.solusi_penyakit,hasil.nilai_kedekatan,hasil.id_hasil,hasil.id_konsultasi')
            ->where('hasil.id_konsultasi', $id_konsultasi)
            ->join('konsultasi', 'konsultasi.id_konsultasi=hasil.id_konsultasi', 'left')
            ->join('penyakit', 'penyakit.id_penyakit=hasil.id_penyakit', 'left')
            ->join('member', 'member.id_member=konsultasi.id_member', 'left')
            ->join('solusi', 'solusi.id_penyakit=penyakit.id_penyakit', 'left')
            ->get('hasil');
    }

    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                DATE_FORMAT(tanggal, '%d-%m-%Y') as tanggal,
                nama,
                nama_penyakit,
                bayar,
                id_hasil,
                acc,
                hasil.id_konsultasi
            FROM
                `hasil`
            LEFT JOIN konsultasi ON konsultasi.id_konsultasi=hasil.id_konsultasi
            LEFT JOIN member ON konsultasi.id_member=member.id_member
            LEFT JOIN penyakit ON penyakit.id_penyakit=hasil.id_penyakit
            , (SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama',
            2 => 'tanggal',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function fetch_data_member($id_member, $column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                DATE_FORMAT(tanggal, '%d-%m-%Y') as tanggal,
                nama,
                nama_penyakit,
                bayar,
                id_hasil,
                acc,
                hasil.id_konsultasi
            FROM
                `hasil`
            LEFT JOIN konsultasi ON konsultasi.id_konsultasi=hasil.id_konsultasi
            LEFT JOIN member ON konsultasi.id_member=member.id_member
            LEFT JOIN penyakit ON penyakit.id_penyakit=hasil.id_penyakit
            , (SELECT @row := 0) r WHERE 1=1
            AND konsultasi.id_member='$id_member'
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama',
            2 => 'tanggal',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function get_baris($id_hasil)
    {
        return $this->db
            ->where('id_hasil', $id_hasil)
            ->join('konsultasi', 'konsultasi.id_konsultasi=hasil.id_konsultasi', 'left')
            ->limit(1)
            ->get('hasil');
    }

    public function get_notifikasi()
    {
        return $this->db
            ->where('notif', TRUE)
            ->get('hasil')
            ->num_rows();
    }

    public function fetch_data_riwayat($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                DATE_FORMAT(tanggal, '%d-%m-%Y') as tanggal,
                nama,
                nama_penyakit,
                nilai_kedekatan,
                nama_kasus,
                id_hasil,
                bukti_transfer,
                acc,
                konsultasi.id_konsultasi
            FROM
                `hasil`
            LEFT JOIN konsultasi ON konsultasi.id_konsultasi=hasil.id_konsultasi
            LEFT JOIN member ON konsultasi.id_member=member.id_member
            LEFT JOIN penyakit ON penyakit.id_penyakit=hasil.id_penyakit
            LEFT JOIN kasus ON kasus.id_kasus=hasil.id_kasus
            , (SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'tanggal',
            2 => 'nama',
            3 => 'nama_penyakit',
            4 => 'nilai_kedekatan',
            5 => 'nama_kasus',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }
}

/* End of file Hasil_model.php */
/* Location: ./application/models/Hasil_model.php */
