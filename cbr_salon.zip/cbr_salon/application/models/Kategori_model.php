<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori_model extends CI_Model
{
    public function get_all()
    {
        return $this->db
            ->order_by('id_kategori', 'asc')
            ->get('kategori');
    }

    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_kategori,
                nama_kategori
            FROM
                `kategori`,(SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama_kategori',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_kategori($dt)
    {
        return $this->db->insert('kategori', $dt);
    }

    public function hapus_kategori($id_kategori)
    {
        return $this->db
            ->where('id_kategori', $id_kategori)
            ->delete('kategori');
    }

    public function get_baris($id_kategori)
    {
        return $this->db
            ->where('id_kategori', $id_kategori)
            ->limit(1)
            ->get('kategori');
    }

    public function update_kategori($id_kategori, $dt)
    {
        return $this->db
            ->where('id_kategori', $id_kategori)
            ->update('kategori', $dt);
    }
}

/* End of file Kategori_model.php */
/* Location: ./application/models/Kategori_model.php */
