<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Konsultasi_model extends CI_Model
{
    public function tambah_konsultasi($dt)
    {
        $this->db->insert('konsultasi', $dt);
        return $this->db->insert_id();
    }

    public function tambah_konsultasi_gejala($dt)
    {
        return $this->db->insert('konsultasi_gejala', $dt);
    }

    public function hapus_konsultasi($id_konsultasi)
    {
        return $this->db
            ->where('id_konsultasi', $id_konsultasi)
            ->delete('konsultasi');
    }

    public function get_baris($id_konsultasi)
    {
        return $this->db
            ->where('id_konsultasi', $id_konsultasi)
            ->limit(1)
            ->get('konsultasi');
    }

    public function update_konsultasi($id_konsultasi, $dt)
    {
        return $this->db
            ->where('id_konsultasi', $id_konsultasi)
            ->update('konsultasi', $dt);
    }

    function get_konsultasi_gejala($id_konsultasi, $id_gejala)
    {
        return $this->db
            ->where('id_konsultasi', $id_konsultasi)
            ->where('konsultasi_gejala.id_gejala', $id_gejala)
            ->join('nilai', 'nilai.id_nilai=konsultasi_gejala.id_nilai', 'left')
            ->get('konsultasi_gejala');
    }
}

/* End of file Konsultasi_model.php */
/* Location: ./application/models/Konsultasi_model.php */
