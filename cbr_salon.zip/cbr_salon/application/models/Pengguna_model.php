<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengguna_model extends CI_Model
{
    public function get_by_username($username)
    {
        $this->db->where('username', $username);
        return $this->db->get('pengguna');
    }

    public function add_pengguna($params)
    {
        $this->db->insert('pengguna', $params);
        return $this->db->insert_id();
    }

    public function get_pengguna($id_pengguna)
    {
        $this->db->where('id_pengguna', $id_pengguna);
        return $this->db->get('pengguna');
    }

    public function update_pengguna($id_pengguna, $dt)
    {
        return $this->db
            ->where('id_pengguna', $id_pengguna)
            ->update('pengguna', $dt);
    }

    public function hapus_pengguna($id_pengguna)
    {
        return $this->db
            ->where('id_pengguna', $id_pengguna)
            ->delete('pengguna');
    }
}

/* End of file Pengguna_model.php */
/* Location: ./application/models/Pengguna_model.php */
