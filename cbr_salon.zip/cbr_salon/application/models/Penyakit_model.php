<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penyakit_model extends CI_Model
{
    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_penyakit,
                kode_penyakit,
                nama_penyakit
            FROM
                `penyakit`, (SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'kode_penyakit',
            2 => 'nama_penyakit',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_penyakit($dt)
    {
        return $this->db->insert('penyakit', $dt);
    }

    public function hapus_penyakit($id_penyakit)
    {
        return $this->db
            ->where('id_penyakit', $id_penyakit)
            ->delete('penyakit');
    }

    public function get_baris($id_penyakit)
    {
        return $this->db
            ->where('id_penyakit', $id_penyakit)
            ->limit(1)
            ->get('penyakit');
    }

    public function update_penyakit($id_penyakit, $dt)
    {
        return $this->db
            ->where('id_penyakit', $id_penyakit)
            ->update('penyakit', $dt);
    }

    public function cek_kode_penyakit($kode_penyakit, $kode_penyakit_tmp)
    {
        $this->db->where('kode_penyakit', $kode_penyakit);
        $this->db->where('kode_penyakit <>', $kode_penyakit_tmp);
        return $this->db->get('penyakit');
    }

    function get_all()
    {
        return $this->db
            ->order_by('nama_penyakit', 'asc')
            ->get('penyakit');
    }
}

/* End of file PenyakitModel.php */
/* Location: ./application/models/PenyakitModel.php */
