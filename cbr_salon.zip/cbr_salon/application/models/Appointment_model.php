<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Appointment_model extends CI_Model
{
    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_appointment,
                nama,
                DATE_FORMAT(tanggal, '%d-%m-%Y') as tanggal,
                jam,
                pesan,
                status,
                keterangan
            FROM
                `appointment`
            LEFT JOIN member ON member.id_member=appointment.id_member
            ,(SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama',
            2 => 'tanggal',
            3 => 'jam',
            4 => 'pesan',
            5 => 'status',
            6 => 'keterangan',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function fetch_data_member($id_member, $column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_appointment,
                nama,
                DATE_FORMAT(tanggal, '%d-%m-%Y') as tanggal,
                jam,
                pesan,
                status,
                keterangan
            FROM
                `appointment`
            LEFT JOIN member ON member.id_member=appointment.id_member
            ,(SELECT @row := 0) r WHERE 1=1
            AND appointment.id_member='$id_member'
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama',
            2 => 'tanggal',
            3 => 'jam',
            4 => 'pesan',
            5 => 'status',
            6 => 'keterangan',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_appointment($dt)
    {
        return $this->db->insert('appointment', $dt);
    }

    public function hapus_appointment($id_appointment)
    {
        return $this->db
            ->where('id_appointment', $id_appointment)
            ->delete('appointment');
    }

    public function get_baris($id_appointment)
    {
        return $this->db
            ->where('id_appointment', $id_appointment)
            ->join('member', 'member.id_member=appointment.id_member', 'left')
            ->limit(1)
            ->get('appointment');
    }

    public function update_appointment($id_appointment, $dt)
    {
        return $this->db
            ->where('id_appointment', $id_appointment)
            ->update('appointment', $dt);
    }

    function get_all()
    {
        return $this->db
            ->order_by('id_appointment', 'asc')
            ->get('appointment');
    }
}

/* End of file Appointment_model.php */
/* Location: ./application/models/Appointment_model.php */
