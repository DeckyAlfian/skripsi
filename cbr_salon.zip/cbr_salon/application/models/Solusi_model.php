<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Solusi_model extends CI_Model
{
    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_solusi,
                solusi_penyakit,
                nama_penyakit
            FROM
                `solusi`
            LEFT JOIN penyakit ON penyakit.id_penyakit=solusi.id_penyakit
            ,(SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama_penyakit',
            2 => 'solusi_penyakit',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_solusi($dt)
    {
        return $this->db->insert('solusi', $dt);
    }

    public function hapus_solusi($id_solusi)
    {
        return $this->db
            ->where('id_solusi', $id_solusi)
            ->delete('solusi');
    }

    public function get_baris($id_solusi)
    {
        return $this->db
            ->where('id_solusi', $id_solusi)
            ->join('penyakit', 'penyakit.id_penyakit=solusi.id_penyakit', 'left')
            ->limit(1)
            ->get('solusi');
    }

    public function update_solusi($id_solusi, $dt)
    {
        return $this->db
            ->where('id_solusi', $id_solusi)
            ->update('solusi', $dt);
    }

    public function cek_id_penyakit($id_penyakit, $id_penyakit_tmp)
    {
        $this->db->where('id_penyakit', $id_penyakit);
        $this->db->where('id_penyakit <>', $id_penyakit_tmp);
        return $this->db->get('solusi');
    }

}

/* End of file Solusi_model.php */
/* Location: ./application/models/Solusi_model.php */
