<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Chat_model extends CI_Model
{
    public function fetch_data($column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_chat,
                nama,
                DATE_FORMAT(tanggal, '%d-%m-%Y') as tanggal,
                judul,
                terakhir_dibalas
            FROM
                `chat`
            LEFT JOIN member ON member.id_member=chat.id_member
            ,(SELECT @row := 0) r WHERE 1=1
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama',
            2 => 'tanggal',
            3 => 'judul',
            4 => 'terakhir_dibalas',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function fetch_data_member($id_member, $column_order = NULL, $column_dir = NULL, $limit_start = NULL, $limit_length = NULL)
    {
        $sql = "
            SELECT
                (@row:=@row+1) AS nomor,
                id_chat,
                nama,
                DATE_FORMAT(tanggal, '%d-%m-%Y') as tanggal,
                judul,
                terakhir_dibalas
            FROM
                `chat`
            LEFT JOIN member ON member.id_member=chat.id_member
            ,(SELECT @row := 0) r WHERE 1=1
            AND chat.id_member='$id_member'
		";

        $data['totalData'] = $this->db->query($sql)->num_rows();

        $data['totalFiltered'] = $this->db->query($sql)->num_rows();

        $columns_order_by = array(
            0 => 'nomor',
            1 => 'nama',
            2 => 'tanggal',
            3 => 'judul',
            4 => 'terakhir_dibalas',
        );

        $sql .= " ORDER BY " . $columns_order_by[$column_order] . " " . $column_dir . ", nomor ";
        $sql .= " LIMIT " . $limit_start . " ," . $limit_length . " ";

        $data['query'] = $this->db->query($sql);
        return $data;
    }

    public function tambah_chat($dt)
    {
        return $this->db->insert('chat', $dt);
    }

    public function tambah_chat_detail($dt)
    {
        return $this->db->insert('chat_detail', $dt);
    }

    public function hapus_chat($id_chat)
    {
        return $this->db
            ->where('id_chat', $id_chat)
            ->delete('chat');
    }

    public function update_chat($id_chat, $dt)
    {
        return $this->db
            ->where('id_chat', $id_chat)
            ->update('chat', $dt);
    }

    public function get_baris($id_chat)
    {
        return $this->db
            ->where('id_chat', $id_chat)
            ->join('member', 'member.id_member=chat.id_member', 'left')
            ->limit(1)
            ->get('chat');
    }

    public function get_chat_detail($id_chat)
    {
        return $this->db
            ->where('chat_detail.id_chat', $id_chat)
            ->join('chat', 'chat.id_chat=chat_detail.id_chat', 'left')
            ->join('member', 'member.id_member=chat.id_member', 'left')
            ->get('chat_detail');
    }

    function get_all()
    {
        return $this->db
            ->order_by('id_chat', 'asc')
            ->get('chat');
    }
}

/* End of file Chat_model.php */
/* Location: ./application/models/Chat_model.php */
