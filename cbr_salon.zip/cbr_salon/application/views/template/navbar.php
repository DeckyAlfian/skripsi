<?php
$CI = &get_instance();
$CI->load->model('hasil_model');
$notif = $CI->hasil_model->get_notifikasi();
?>
<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light rounded">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-bs">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-bs">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item <?php echo $this->uri->segment(1) == '' || $this->uri->segment(1) == 'home' ? 'active' : ''; ?>">
                    <a class="nav-link" href="<?php echo site_url('home'); ?>">Home</a>
                </li>

                <?php if ($this->session->userdata('logged_in')) { ?>

                    <?php if ($this->session->userdata('level') == "Admin") { ?>
                        <li class="nav-item dropdown <?php echo $this->uri->segment(1) == 'member' || $this->uri->segment(1) == 'kategori' || $this->uri->segment(1) == 'gejala' || $this->uri->segment(1) == 'penyakit' || $this->uri->segment(1) == 'solusi' ? 'active' : ''; ?>">
                            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Data Master</a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item <?php echo $this->uri->segment(1) == 'member' ? 'active' : ''; ?>" href="<?php echo site_url('member'); ?>">Member</a>
                                <a class="dropdown-item <?php echo $this->uri->segment(1) == 'kategori' ? 'active' : ''; ?>" href="<?php echo site_url('kategori'); ?>">Kategori Gejala</a>
                                <a class="dropdown-item <?php echo $this->uri->segment(1) == 'gejala' ? 'active' : ''; ?>" href="<?php echo site_url('gejala'); ?>">Gejala</a>
                                <a class="dropdown-item <?php echo $this->uri->segment(1) == 'penyakit' ? 'active' : ''; ?>" href="<?php echo site_url('penyakit'); ?>">Penyakit</a>
                                <a class="dropdown-item <?php echo $this->uri->segment(1) == 'solusi' ? 'active' : ''; ?>" href="<?php echo site_url('solusi'); ?>">Solusi</a>
                            </div>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'kasus' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('kasus'); ?>">Data Kasus</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'riwayat' ? 'active' : ''; ?>">
                            <?= empty($notif) ? '' : '<span class="badge badge-pill badge-danger" style="float:right;margin-bottom:-10px;">' . $notif . '</span>' ?>
                            <a class="nav-link" href="<?php echo site_url('riwayat'); ?>">Riwayat Konsultasi</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'appointment' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('appointment'); ?>">Appointment</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'chat' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('chat'); ?>">Chat Konsultasi</a>
                        </li>

                    <?php } elseif ($this->session->userdata('level') == "Member") { ?>

                        <li class="nav-item <?php echo $this->uri->segment(1) == 'daftar-penyakit' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('daftar-penyakit'); ?>">Daftar Penyakit</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'informasi-solusi' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('informasi-solusi'); ?>">Informasi Solusi</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'konsultasi' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('konsultasi'); ?>">Konsultasi</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'hasil-konsultasi' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('hasil-konsultasi'); ?>">Hasil Konsultasi</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'appointment' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('appointment'); ?>">Appointment</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1) == 'chat' ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo site_url('chat'); ?>">Chat Konsultasi</a>
                        </li>

                    <?php } ?>

                <?php } else { ?>

                    <li class="nav-item <?php echo $this->uri->segment(1) == 'daftar-penyakit' ? 'active' : ''; ?>">
                        <a class="nav-link" href="<?php echo site_url('daftar-penyakit'); ?>">Daftar Penyakit</a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1) == 'informasi-solusi' ? 'active' : ''; ?>">
                        <a class="nav-link" href="<?php echo site_url('informasi-solusi'); ?>">Informasi Solusi</a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1) == 'konsultasi' ? 'active' : ''; ?>">
                        <a class="nav-link" href="<?php echo site_url('konsultasi'); ?>">Konsultasi</a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1) == 'hasil-konsultasi' ? 'active' : ''; ?>">
                        <a class="nav-link" href="<?php echo site_url('hasil-konsultasi'); ?>">Hasil Konsultasi</a>
                    </li>

                <?php } ?>

            </ul>
            <ul class="navbar-nav">
                <?php if ($this->session->userdata('logged_in')) { ?>
                    <li class="nav-item active">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                            <i class="fas fa-user fa-fw"></i> <?php echo $this->session->userdata('nama_lengkap'); ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="<?php echo site_url('password'); ?>">Ubah Password</a>
                            <a class="dropdown-item" href="<?php echo site_url('logout'); ?>">Logout</a>
                        </div>
                    </li>
                <?php } else { ?>
                    <li class="nav-item <?php echo $this->uri->segment(1) == 'registrasi' ? 'active' : ''; ?>">
                        <a class="nav-link" href="<?php echo site_url('registrasi'); ?>">Daftar Member</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('login'); ?>">Login</a>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </nav>
</div>