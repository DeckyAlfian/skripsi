<div class="modal fade" id="BsModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalHeader"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class='fa fa-times-circle'></i></button>
            </div>
            <div class="modal-body" id="ModalContent"></div>
            <div class="modal-footer" id="ModalFooter"></div>
        </div>
    </div>
</div>

<script>
    $('#BsModal').on('hide.bs.modal', function() {
        setTimeout(function() {
            $('#ModalHeader, #ModalContent, #ModalFooter').html('');
        }, 500);
    });
</script>

</body>

</html>