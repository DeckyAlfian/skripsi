<?php $this->load->view('template_admin/header'); ?>

<div class="card border-0 shadow">
    <div class="card-body text-center">
        <h2 class="font-weight-bold">
            SISTEM PENDUKUNG KEPUTUSAN<br>
            PERAWATAN KECANTIKAN DI FIRMAN SALON
        </h2>
        <p class="lead">Menggunakan Metode Case Based Reasoning</p>
        <img src="<?php echo base_url('assets/images/logo.png'); ?>" alt="Logo" width="300">
        <br>
        <br>
        <br>
    </div>
</div>

<?php $this->load->view('template_admin/js'); ?>
<?php $this->load->view('template_admin/footer'); ?>