<?php
$CI = &get_instance();
$CI->load->model('hasil_model');
$notif = $CI->hasil_model->get_notifikasi();
?>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'home' ? 'active' : ''; ?>" href="<?php echo site_url('admin/home'); ?>" role="tab">Home</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'member' ? 'active' : ''; ?>" href="<?php echo site_url('admin/member'); ?>" role="tab">Member</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'kategori' ? 'active' : ''; ?>" href="<?php echo site_url('admin/kategori'); ?>" role="tab">Kategori Gejala</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'gejala' ? 'active' : ''; ?>" href="<?php echo site_url('admin/gejala'); ?>" role="tab">Gejala</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'penyakit' ? 'active' : ''; ?>" href="<?php echo site_url('admin/penyakit'); ?>" role="tab">Penyakit</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'solusi' ? 'active' : ''; ?>" href="<?php echo site_url('admin/solusi'); ?>" role="tab">Solusi</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'kasus' ? 'active' : ''; ?>" href="<?php echo site_url('admin/kasus'); ?>" role="tab">Data Kasus</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'riwayat' ? 'active' : ''; ?>" href="<?php echo site_url('admin/riwayat'); ?>" role="tab">Riwayat Konsultasi <span class="badge badge-danger badge-pill text-right"><?= empty($notif) ? '' : $notif ?></span></a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'appointment' ? 'active' : ''; ?>" href="<?php echo site_url('admin/appointment'); ?>" role="tab">Appointment</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'chat' ? 'active' : ''; ?>" href="<?php echo site_url('admin/chat'); ?>" role="tab">Chat Konsultasi</a>
<a class="list-group-item list-group-item-action <?php echo $this->uri->segment(1) == 'admin' && $this->uri->segment(2) == 'password' ? 'active' : ''; ?>" href="<?php echo site_url('admin/password'); ?>" role="tab">Ubah Password</a>
<a class="list-group-item list-group-item-action" href="<?php echo site_url('logout'); ?>" role="tab">Logout</a>