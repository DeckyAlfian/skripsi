<?php echo form_open('admin/penyakit/edit-penyakit/'.$penyakit->id_penyakit, array('id' => 'FormEditPenyakit')); ?>
<?php echo form_hidden('kode_penyakit_tmp', $penyakit->kode_penyakit); ?>
<div class="form-group row">
    <label for="kode_penyakit" class="col-md-3 col-form-label">Kode Penyakit</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="kode_penyakit" name="kode_penyakit" value="<?php echo set_value('kode_penyakit', $penyakit->kode_penyakit); ?>">
    </div>
</div>
<div class="form-group row">
    <label for="nama_penyakit" class="col-md-3 col-form-label">Nama Penyakit</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_penyakit" name="nama_penyakit" value="<?php echo set_value('nama_penyakit', $penyakit->nama_penyakit); ?>">
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
function EditPenyakit()
{
	$.ajax({
		url: $('#FormEditPenyakit').attr('action'),
		type: "POST",
		cache: false,
		data: $('#FormEditPenyakit').serialize(),
		dataType:'json',
		success: function(json){
			if(json.status == 1){
				$('#ResponseInput').html(json.pesan);
				setTimeout(function(){
			   		$('#ResponseInput').html('');
			    }, 3000);
				$('#my-grid').DataTable().ajax.reload( null, false );
			}
			else {
				$('#ResponseInput').html(json.pesan);
			}
		}
	});
}

$(document).ready(function(){
	var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
	Tombol += "<button type='button' class='btn btn-success' id='SimpanEditPenyakit'>Ubah</button>";
	$('#ModalFooter').html(Tombol);

	$('#SimpanEditPenyakit').click(function(e){
		e.preventDefault();
		EditPenyakit();
	});

	$('#FormEditPenyakit').submit(function(e){
		e.preventDefault();
		EditPenyakit();
	});
});
</script>