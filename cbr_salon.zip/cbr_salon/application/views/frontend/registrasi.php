<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body p-3">
            <h2 class="card-title text-center">Pendaftaran Member</h2>
            <div class="row d-flex justify-content-center">
                <div class="col-md-6">

                    <?php echo $this->session->flashdata('success'); ?>

                    <form action="<?php echo site_url('registrasi'); ?>" method="POST" class="mt-2">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control <?php echo form_error('nama') != '' ? 'is-invalid' : ''; ?>" id="nama" name="nama" value="<?php echo set_value('nama'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('nama'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" class="form-control <?php echo form_error('alamat') != '' ? 'is-invalid' : ''; ?>" id="alamat" name="alamat" value="<?php echo set_value('alamat'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('alamat'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="jenis_kelamin">Jenis Kelamin</label>
                            <select class="form-control <?php echo form_error('jenis_kelamin') != '' ? 'is-invalid' : ''; ?>" name="jenis_kelamin" id="jenis_kelamin">
                                <option value="">Pilih...</option>
                                <option value="Laki-Laki" <?php echo set_select('jenis_kelamin', 'Laki-Laki'); ?>>Laki-Laki</option>
                                <option value="Perempuan" <?php echo set_select('jenis_kelamin', 'Perempuan'); ?>>Perempuan</option>
                            </select>
                            <div class="invalid-feedback">
                                <?php echo form_error('jenis_kelamin'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="no_hp">No HP</label>
                            <input type="text" class="form-control <?php echo form_error('no_hp') != '' ? 'is-invalid' : ''; ?>" id="no_hp" name="no_hp" value="<?php echo set_value('no_hp'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('no_hp'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control <?php echo form_error('username') != '' ? 'is-invalid' : ''; ?>" id="username" name="username" value="<?php echo set_value('username'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('username'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control <?php echo form_error('password') != '' ? 'is-invalid' : ''; ?>" id="password" name="password" value="<?php echo set_value('password'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('password'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Ulangi Password</label>
                            <input type="password" class="form-control <?php echo form_error('confirm_password') != '' ? 'is-invalid' : ''; ?>" id="confirm_password" name="confirm_password" value="<?php echo set_value('confirm_password'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('confirm_password'); ?>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" name="register" class="btn btn-outline-success">Daftar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>
<?php $this->load->view('template/footer'); ?>