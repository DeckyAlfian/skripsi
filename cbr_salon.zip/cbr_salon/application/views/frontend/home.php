<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body p-3 text-center">
            <h2 class="font-weight-bold">
                SISTEM PENDUKUNG KEPUTUSAN<br>
                PERAWATAN KECANTIKAN DI FIRMAN SALON
            </h2>
            <p class="lead">Menggunakan Metode Case Based Reasoning</p>
            <img src="<?php echo base_url('assets/images/logo.png'); ?>" alt="Logo" width="300">
            <br>
            <br>
            <br>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>
<?php $this->load->view('template/footer'); ?>