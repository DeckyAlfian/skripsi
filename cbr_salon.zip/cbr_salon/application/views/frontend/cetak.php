<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Cetak Hasil Konsultasi</title>

    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 14px;
        }

        th {
            height: 30px;
            text-align: center;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 3px;
        }

        thead {
            background: lightgray;
        }

        .center {
            text-align: center;
        }
    </style>
</head>

<body>
    <h2 class="center">LAPORAN HASIL KONSULTASI</h2>
    <table>
        <tr>
            <td width="100">Id Konsultasi</td>
            <td><?php echo $hasil->id_konsultasi; ?></td>
        </tr>
        <tr>
            <td width="100">Nama</td>
            <td><?php echo $hasil->nama; ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><?php echo $hasil->alamat; ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td><?php echo $hasil->jenis_kelamin; ?></td>
        </tr>
        <tr>
            <td>No HP</td>
            <td><?php echo $hasil->no_hp; ?></td>
        </tr>
        <tr>
            <td>Penyakit</td>
            <td><?php echo $hasil->nama_penyakit; ?></td>
        </tr>
        <tr>
            <td>Nilai Kedekatan</td>
            <td><?php echo $hasil->nilai_kedekatan; ?></td>
        </tr>
        <tr>
            <td>Solusi</td>
            <td><?php echo $hasil->solusi_penyakit; ?></td>
        </tr>
    </table>
</body>

</html>