<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body">
            <h4 class="card-title">Hasil Konsultasi</h4>
            <div class="row">
                <div class="col">
                    <?php if ($this->session->userdata('logged_in') == FALSE) : ?>
                        <p>Silahkan <?= anchor('login', 'Login') ?> untuk melihat hasil konsultasi</p>
                    <?php else : ?>
                        <div class="d-flex justify-content-center">
                            <span id='notifikasi' style='display: none;'></span>
                        </div>
                        <div class="table-responsive">
                            <table id="my-grid" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Id Konsultasi</th>
                                        <th>Tanggal</th>
                                        <th>Member</th>
                                        <th class="no-sort">Penyakit</th>
                                        <th class="no-sort">Cetak</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>

<script src="<?php echo base_url('assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables/js/dataTables.bootstrap4.min.js'); ?>"></script>
<script>
    $(document).ready(function() {
        var dataTable = $('#my-grid').DataTable({
            "serverSide": true,
            "stateSave": false,
            "bAutoWidth": true,
            "oLanguage": {
                "sEmptyTable": "Tidak ada data",
                "sLoadingRecords": "Harap Tunggu...",
                "oPaginate": {
                    "sPrevious": "Sebelumnya",
                    "sNext": "Selanjutnya"
                }
            },
            "aaSorting": [
                [1, "desc"]
            ],
            "columnDefs": [{
                "targets": 'no-sort',
                "orderable": false,
            }],
            "lengthChange": false,
            "bInfo": false,
            "searching": false,
            "sPaginationType": "simple_numbers",
            "ajax": {
                url: "<?php echo site_url('frontend/list-hasil-json'); ?>",
                type: "post",
                error: function() {
                    $(".my-grid-error").html("");
                    $("#my-grid").append('<tbody class="my-grid-error"><tr><th colspan="4">Data tidak ditemukan</th></tr></tbody>');
                    $("#my-grid_processing").css("display", "none");
                }
            }
        });
    });
    $(document).on('click', '#bayar', function(e) {
        e.preventDefault();
        var data = "<p>Atas Nama</p><p>Bank Mandiri</p><p>1234567891234</p>"
        $('#ModalHeader').html('Informasi Pembayaran');
        $('#ModalContent').html(data);
        $('#BsModal').modal('show');
    });
</script>

<?php $this->load->view('template/footer'); ?>