<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body">
            <h4 class="card-title">Daftar Penyakit</h4>
            <div class="row">
                <div class="col">
                    <div class="d-flex justify-content-center">
                        <span id='notifikasi' style='display: none;'></span>
                    </div>
                    <div class="table-responsive">
                        <table id="my-grid" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kode Penyakit</th>
                                    <th>Nama Penyakit</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>

<script src="<?php echo base_url('assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables/js/dataTables.bootstrap4.min.js'); ?>"></script>
<script>
    $(document).ready(function() {
        var dataTable = $('#my-grid').DataTable({
            "serverSide": true,
            "stateSave": false,
            "bAutoWidth": true,
            "oLanguage": {
                "sEmptyTable": "Tidak ada data",
                "sLoadingRecords": "Harap Tunggu...",
                "oPaginate": {
                    "sPrevious": "Sebelumnya",
                    "sNext": "Selanjutnya"
                }
            },
            "aaSorting": [
                [0, "desc"]
            ],
            "columnDefs": [{
                "targets": 'no-sort',
                "orderable": false,
            }],
            "lengthChange": false,
            "bInfo": false,
            "searching": false,
            "sPaginationType": "simple_numbers",
            "ajax": {
                url: "<?php echo site_url('frontend/list-penyakit-json'); ?>",
                type: "post",
                error: function() {
                    $(".my-grid-error").html("");
                    $("#my-grid").append('<tbody class="my-grid-error"><tr><th colspan="3">Data tidak ditemukan</th></tr></tbody>');
                    $("#my-grid_processing").css("display", "none");
                }
            }
        });
    });
</script>

<?php $this->load->view('template/footer'); ?>