<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body">
            <h4 class="card-title">Upload Bukti Transfer</h4>
            <div class="row">
                <div class="col">
                    <?php echo form_open_multipart('bukti-transfer/' . $id_hasil); ?>
                    <div class="form-group row">
                        <label for="userfile" class="col-md-2 col-form-label">Bukti Transfer</label>
                        <div class="col-md-10">
                            <input type="file" class="form-control <?php echo form_error('userfile') != '' ? 'is-invalid' : ''; ?>" name="userfile">
                            <small>Ekstensi file yang diijinkan (JPG,JPEG,PNG). Ukuran file maksimal 2 MB.</small>
                            <div class="invalid-feedback">
                                <?php echo form_error('userfile'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-10"><button type="submit" name="simpan" class="btn btn-outline-success">Upload</button></div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>
<?php $this->load->view('template/footer'); ?>