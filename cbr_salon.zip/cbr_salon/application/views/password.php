<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body p-3">
            <h2 class="card-title text-center">Ubah Password</h2>
            <div class="row d-flex justify-content-center">
                <div class="col-md-6">

                    <?php echo $this->session->flashdata('success'); ?>

                    <form action="<?php echo site_url('password'); ?>" method="POST" class="mt-2">
                        <div class="form-group">
                            <label for="password_lama">Password Lama</label>
                            <input type="password" class="form-control <?php echo form_error('password_lama') != '' ? 'is-invalid' : ''; ?>" id="password_lama" name="password_lama" value="<?php echo set_value('password_lama'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('password_lama'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password_baru">Password Baru</label>
                            <input type="password" class="form-control <?php echo form_error('password_baru') != '' ? 'is-invalid' : ''; ?>" id="password_baru" name="password_baru" value="<?php echo set_value('password_baru'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('password_baru'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="ulangi_password">Ulangi Password Baru</label>
                            <input type="password" class="form-control <?php echo form_error('ulangi_password') != '' ? 'is-invalid' : ''; ?>" id="ulangi_password" name="ulangi_password" value="<?php echo set_value('ulangi_password'); ?>">
                            <div class="invalid-feedback">
                                <?php echo form_error('ulangi_password'); ?>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" name="save" class="btn btn-outline-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>
<?php $this->load->view('template/footer'); ?>