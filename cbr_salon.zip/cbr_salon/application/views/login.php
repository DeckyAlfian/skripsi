<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Sistem Pendukung Keputusan Perawatan Kecantikan Di Firman Salon Menggunakan Metode Case Based Reasoning</title>

    <link href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/login.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/images/logo.png'); ?>" rel="icon" type="image/png">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card card-signin my-5">
                    <div class="card-body">
                        <h5 class="card-title text-center text-uppercase font-weight-bold">User Login</h5>
                        <form action="<?php echo site_url('login'); ?>" method="POST" class="mt-2">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control <?php echo form_error('username') != '' ? 'is-invalid' : ''; ?>" id="username" name="username" placeholder="Masukkan username">
                                <div class="invalid-feedback">
                                    <?php echo form_error('username'); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control <?php echo form_error('password') != '' ? 'is-invalid' : ''; ?>" id="password" name="password" placeholder="Masukkan password">
                                <div class="invalid-feedback">
                                    <?php echo form_error('password'); ?>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button type="submit" name="login" class="btn btn-outline-success">Login</button>
                            </div>
                            <div class="d-flex justify-content-start">
                                <p class="mt-2">Belum jadi member? <a href="<?php echo site_url('registrasi'); ?>" class="font-weight-bold"><u>Daftar</u></a></p>
                            </div>
                            <div class="d-flex justify-content-start">
                                <p class="mt-2">Kembali ke <a href="<?php echo site_url('home'); ?>" class="font-weight-bold"><u>Halaman Home</u></a></p>
                            </div>
                            <?php echo $this->session->flashdata('error'); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>