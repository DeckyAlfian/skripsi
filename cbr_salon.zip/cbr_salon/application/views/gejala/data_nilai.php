<?php $this->load->view('template_admin/header'); ?>

<div class="card border-0 shadow">
    <div class="card-body">
        <h4 class="card-title">Nilai Gejala</h4>
        <div class="row">
            <div class="col">
                <table class="table table-bordered plain">
                    <tr>
                        <td width="120">Kode Gejala</td>
                        <td><?php echo $gejala->kode_gejala; ?></td>
                    </tr>
                    <tr>
                        <td width="120">Nama Gejala</td>
                        <td><?php echo $gejala->nama_gejala; ?></td>
                    </tr>
                    <tr>
                        <td width="120">Bobot</td>
                        <td><?php echo $gejala->bobot; ?></td>
                    </tr>
                    <tr>
                        <td width="120">Kategori</td>
                        <td><?php echo $gejala->nama_kategori; ?></td>
                    </tr>
                </table>
                <div class="d-flex justify-content-end">
                    <a href="<?php echo site_url('admin/gejala'); ?>" class="btn btn-secondary">Kembali</a> &nbsp;
                    <a href="<?php echo site_url('admin/gejala/nilai-kedekatan/' . $id_gejala); ?>" class="btn btn-info">Nilai Kedekatan</a> &nbsp;
                    <a href="<?php echo site_url('admin/gejala/tambah-gejala-nilai/' . $id_gejala); ?>" class="btn btn-primary" id="TambahGejalaNilai">Tambah Data Nilai</a>
                </div>
                <div class="d-flex justify-content-center">
                    <span id='notifikasi' style='display: none;'></span>
                </div>
                <div class="table-responsive">
                    <table id="my-grid" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Nilai</th>
                                <th class='no-sort'>Proses</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template_admin/js'); ?>

<script src="<?php echo base_url('assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables/js/dataTables.bootstrap4.min.js'); ?>"></script>
<script>
    $(document).ready(function() {
        var dataTable = $('#my-grid').DataTable({
            "serverSide": true,
            "stateSave": false,
            "bAutoWidth": true,
            "oLanguage": {
                "sEmptyTable": "Tidak ada data",
                "sLoadingRecords": "Harap Tunggu...",
                "oPaginate": {
                    "sPrevious": "Sebelumnya",
                    "sNext": "Selanjutnya"
                }
            },
            "aaSorting": [
                [0, "desc"]
            ],
            "columnDefs": [{
                "targets": 'no-sort',
                "orderable": false,
            }],
            "lengthChange": false,
            "bInfo": false,
            "searching": false,
            "sPaginationType": "simple_numbers",
            "ajax": {
                url: "<?php echo site_url('admin/gejala/list-gejala-nilai-json/' . $id_gejala); ?>",
                type: "post",
                error: function() {
                    $(".my-grid-error").html("");
                    $("#my-grid").append('<tbody class="my-grid-error"><tr><th colspan="3">Data tidak ditemukan</th></tr></tbody>');
                    $("#my-grid_processing").css("display", "none");
                }
            }
        });
    });

    $(document).on('click', '#HapusGejalaNilai', function(e) {
        e.preventDefault();
        var Link = $(this).attr('href');

        $('#ModalHeader').html('Konfirmasi');
        $('#ModalContent').html('Apakah anda yakin ingin menghapus <b>' + $(this).parent().parent().find('td:nth-child(2)').html() + '</b> ?');
        $('#ModalFooter').html("<button type='button' class='btn btn-secondary' data-dismiss='modal'>Batal</button><button type='button' class='btn btn-danger' id='YesDeleteGejalaNilai' data-url='" + Link + "'>Hapus</button>");
        $('#BsModal').modal('show');
    });

    $(document).on('click', '#YesDeleteGejalaNilai', function(e) {
        e.preventDefault();
        $('#BsModal').modal('hide');

        $.ajax({
            url: $(this).data('url'),
            type: "POST",
            cache: false,
            dataType: 'json',
            success: function(data) {
                $('#notifikasi').html(data.pesan);
                $("#notifikasi").fadeIn('fast').show().delay(3000).fadeOut('fast');
                $('#my-grid').DataTable().ajax.reload(null, false);
            }
        });
    });

    $(document).on('click', '#TambahGejalaNilai, #EditGejalaNilai', function(e) {
        e.preventDefault();

        if ($(this).attr('id') == 'TambahGejalaNilai') {
            $('#ModalHeader').html('Tambah Nilai Gejala');
        }
        if ($(this).attr('id') == 'EditGejalaNilai') {
            $('#ModalHeader').html('Ubah Nilai Gejala');
        }
        $('#ModalContent').load($(this).attr('href'));
        $('#BsModal').modal('show');
    });
</script>

<?php $this->load->view('template_admin/footer'); ?>