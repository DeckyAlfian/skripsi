<?php echo form_open('admin/gejala/tambah-gejala-nilai/'.$id_gejala, array('id' => 'FormTambahGejalaNilai')); ?>
<div class="form-group row">
    <label for="nama_nilai" class="col-md-3 col-form-label">Nama Nilai</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_nilai" name="nama_nilai">
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
    function TambahGejalaNilai() {
        $.ajax({
            url: $('#FormTambahGejalaNilai').attr('action'),
            type: "POST",
            cache: false,
            data: $('#FormTambahGejalaNilai').serialize(),
            dataType: 'json',
            success: function(json) {
                if (json.status == 1) {
                    $('#ResponseInput').html(json.pesan);
                    setTimeout(function() {
                        $('#ResponseInput').html('');
                    }, 3000);
                    $('#my-grid').DataTable().ajax.reload(null, false);

                    $('#FormTambahGejalaNilai').each(function() {
                        this.reset();
                    });
                } else {
                    $('#ResponseInput').html(json.pesan);
                }
            }
        });
    }

    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        Tombol += "<button type='button' class='btn btn-success' id='SimpanTambahGejalaNilai'>Tambah</button>";
        $('#ModalFooter').html(Tombol);

        $('#SimpanTambahGejalaNilai').click(function(e) {
            e.preventDefault();
            TambahGejalaNilai();
        });

        $('#FormTambahGejalaNilai').submit(function(e) {
            e.preventDefault();
            TambahGejalaNilai();
        });
    });
</script>