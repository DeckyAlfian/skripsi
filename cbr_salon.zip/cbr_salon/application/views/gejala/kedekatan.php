<?php $this->load->view('template_admin/header'); ?>

<div class="card border-0 shadow">
    <div class="card-body">
        <h4 class="card-title">Nilai Kedekatan</h4>
        <div class="row">
            <div class="col">
                <table class="table table-bordered plain">
                    <tr>
                        <td width="120">Kode Gejala</td>
                        <td><?php echo $gejala->kode_gejala; ?></td>
                    </tr>
                    <tr>
                        <td width="120">Nama Gejala</td>
                        <td><?php echo $gejala->nama_gejala; ?></td>
                    </tr>
                    <tr>
                        <td width="120">Bobot</td>
                        <td><?php echo $gejala->bobot; ?></td>
                    </tr>
                    <tr>
                        <td width="120">Kategori</td>
                        <td><?php echo $gejala->nama_kategori; ?></td>
                    </tr>
                </table>
                <div class="d-flex justify-content-end mb-2">
                    <a href="<?php echo site_url('admin/gejala/nilai-gejala/' . $id_gejala); ?>" class="btn btn-secondary">Kembali</a>
                </div>
                <?php echo $this->session->flashdata('success'); ?>
                <form class="mt-2" action="<?php echo site_url('admin/gejala/nilai-kedekatan/' . $id_gejala); ?>" method="post">
                    <div class="table-responsive">
                        <table class="table table-bordered tabel-header plain">
                            <thead>
                                <tr>
                                    <th>Nama Nilai</th>
                                    <th>Nilai Kedekatan</th>
                                    <th>Nama Nilai</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0; ?>
                                <?php foreach ($nilai1 as $n1) : ?>
                                    <?php $ii = 0; ?>
                                    <?php foreach ($nilai2 as $n2) : ?>
                                        <?php if ($i <= $ii) : ?>
                                            <tr>
                                                <td class="td-right" style="width: 43%"><?php echo $n1->nama_nilai; ?></td>
                                                <td class="td-center" style="width: 13%">
                                                    <input type="number" step="0.01" required class="text-center form-control form-control-sm" name="nilai_<?php echo $n1->id_nilai; ?>_<?php echo $n2->id_nilai; ?>" value="<?php echo floatval($nilai[$i][$ii]); ?>">
                                                </td>
                                                <td class="td-left" style="width: 43%"><?php echo $n2->nama_nilai; ?></td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php $ii++; ?>
                                    <?php endforeach; ?>
                                    <?php $i++; ?>
                                <?php endforeach; ?>
                                <tr>
                                    <td class="td-center" colspan="3">
                                        <button type="submit" name="save" class="btn btn-success">Simpan</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template_admin/js'); ?>

<?php $this->load->view('template_admin/footer'); ?>