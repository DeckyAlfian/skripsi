<?php echo form_open('admin/gejala/edit-gejala/'.$gejala->id_gejala, array('id' => 'FormEditGejala')); ?>
<?php echo form_hidden('kode_gejala_tmp', $gejala->kode_gejala); ?>
<div class="form-group row">
    <label for="kode_gejala" class="col-md-3 col-form-label">Kode Gejala</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="kode_gejala" name="kode_gejala" value="<?php echo set_value('kode_gejala', $gejala->kode_gejala); ?>">
    </div>
</div>
<div class="form-group row">
    <label for="nama_gejala" class="col-md-3 col-form-label">Nama Gejala</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_gejala" name="nama_gejala" value="<?php echo set_value('nama_gejala', $gejala->nama_gejala); ?>">
    </div>
</div>
<div class="form-group row">
    <label for="bobot" class="col-md-3 col-form-label">Bobot</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="bobot" name="bobot" value="<?php echo set_value('bobot', $gejala->bobot); ?>">
    </div>
</div>
<div class="form-group row">
    <label for="id_kategori" class="col-md-3 col-form-label">Kategori</label>
    <div class="col-md-9">
        <select name="id_kategori" id="id_kategori" class="form-control">
            <option value="">Pilih...</option>
            <?php foreach($kategori as $k): ?>
                <option value="<?php echo $k->id_kategori; ?>" <?php echo set_select('id_kategori', $k->id_kategori, $gejala->id_kategori == $k->id_kategori ? TRUE : FALSE); ?>><?php echo $k->nama_kategori; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
function EditGejala()
{
	$.ajax({
		url: $('#FormEditGejala').attr('action'),
		type: "POST",
		cache: false,
		data: $('#FormEditGejala').serialize(),
		dataType:'json',
		success: function(json){
			if(json.status == 1){
				$('#ResponseInput').html(json.pesan);
				setTimeout(function(){
			   		$('#ResponseInput').html('');
			    }, 3000);
				$('#my-grid').DataTable().ajax.reload( null, false );
			}
			else {
				$('#ResponseInput').html(json.pesan);
			}
		}
	});
}

$(document).ready(function(){
	var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
	Tombol += "<button type='button' class='btn btn-success' id='SimpanEditGejala'>Ubah</button>";
	$('#ModalFooter').html(Tombol);

	$('#SimpanEditGejala').click(function(e){
		e.preventDefault();
		EditGejala();
	});

	$('#FormEditGejala').submit(function(e){
		e.preventDefault();
		EditGejala();
	});
});
</script>