<?php echo form_open('admin/gejala/edit-gejala-nilai/'.$nilai->id_nilai, array('id' => 'FormEditGejalaNilai')); ?>
<div class="form-group row">
    <label for="nama_nilai" class="col-md-3 col-form-label">Nama Nilai</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_nilai" name="nama_nilai" value="<?php echo set_value('nama_nilai', $nilai->nama_nilai); ?>">
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
function EditGejalaNilai()
{
	$.ajax({
		url: $('#FormEditGejalaNilai').attr('action'),
		type: "POST",
		cache: false,
		data: $('#FormEditGejalaNilai').serialize(),
		dataType:'json',
		success: function(json){
			if(json.status == 1){
				$('#ResponseInput').html(json.pesan);
				setTimeout(function(){
			   		$('#ResponseInput').html('');
			    }, 3000);
				$('#my-grid').DataTable().ajax.reload( null, false );
			}
			else {
				$('#ResponseInput').html(json.pesan);
			}
		}
	});
}

$(document).ready(function(){
	var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
	Tombol += "<button type='button' class='btn btn-success' id='SimpanEditGejalaNilai'>Ubah</button>";
	$('#ModalFooter').html(Tombol);

	$('#SimpanEditGejalaNilai').click(function(e){
		e.preventDefault();
		EditGejalaNilai();
	});

	$('#FormEditGejalaNilai').submit(function(e){
		e.preventDefault();
		EditGejalaNilai();
	});
});
</script>