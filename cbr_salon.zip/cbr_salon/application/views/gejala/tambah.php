<?php echo form_open('admin/gejala/tambah-gejala', array('id' => 'FormTambahGejala')); ?>
<div class="form-group row">
    <label for="kode_gejala" class="col-md-3 col-form-label">Kode Gejala</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="kode_gejala" name="kode_gejala">
    </div>
</div>
<div class="form-group row">
    <label for="nama_gejala" class="col-md-3 col-form-label">Nama Gejala</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_gejala" name="nama_gejala">
    </div>
</div>
<div class="form-group row">
    <label for="bobot" class="col-md-3 col-form-label">Bobot</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="bobot" name="bobot">
    </div>
</div>
<div class="form-group row">
    <label for="id_kategori" class="col-md-3 col-form-label">Kategori</label>
    <div class="col-md-9">
        <select name="id_kategori" id="id_kategori" class="form-control">
            <option value="">Pilih...</option>
            <?php foreach($kategori as $k): ?>
                <option value="<?php echo $k->id_kategori; ?>" <?php echo set_select('id_kategori', $k->id_kategori); ?>><?php echo $k->nama_kategori; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
    function TambahGejala() {
        $.ajax({
            url: $('#FormTambahGejala').attr('action'),
            type: "POST",
            cache: false,
            data: $('#FormTambahGejala').serialize(),
            dataType: 'json',
            success: function(json) {
                if (json.status == 1) {
                    $('#ResponseInput').html(json.pesan);
                    setTimeout(function() {
                        $('#ResponseInput').html('');
                    }, 3000);
                    $('#my-grid').DataTable().ajax.reload(null, false);

                    $('#FormTambahGejala').each(function() {
                        this.reset();
                    });
                } else {
                    $('#ResponseInput').html(json.pesan);
                }
            }
        });
    }

    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        Tombol += "<button type='button' class='btn btn-success' id='SimpanTambahGejala'>Tambah</button>";
        $('#ModalFooter').html(Tombol);

        $('#SimpanTambahGejala').click(function(e) {
            e.preventDefault();
            TambahGejala();
        });

        $('#FormTambahGejala').submit(function(e) {
            e.preventDefault();
            TambahGejala();
        });
    });
</script>