<?php echo form_open('admin/member/edit-member/'.$member->id_member, array('id' => 'FormEditMember')); ?>
<div class="form-group row">
    <label for="nama" class="col-md-3 col-form-label">Nama</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo set_value('nama', $member->nama); ?>">
    </div>
</div>
<div class="form-group row">
    <label for="alamat" class="col-md-3 col-form-label">Alamat</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo set_value('alamat', $member->alamat); ?>">
    </div>
</div>
<div class="form-group row">
    <label for="jenis_kelamin" class="col-md-3 col-form-label">Jenis Kelamin</label>
    <div class="col-md-9">
        <select class="form-control" name="jenis_kelamin" id="jenis_kelamin">
            <option value="">Pilih...</option>
            <option value="Laki-Laki" <?php echo set_select('jenis_kelamin', 'Laki-Laki', $member->jenis_kelamin == 'Laki-Laki' ? TRUE : FALSE); ?>>Laki-Laki</option>
            <option value="Perempuan" <?php echo set_select('jenis_kelamin', 'Perempuan', $member->jenis_kelamin == 'Perempuan' ? TRUE : FALSE); ?>>Perempuan</option>
        </select>
    </div>
</div>
<div class="form-group row">
    <label for="no_hp" class="col-md-3 col-form-label">No HP</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="no_hp" name="no_hp" value="<?php echo set_value('no_hp', $member->no_hp); ?>">
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
function EditMember()
{
	$.ajax({
		url: $('#FormEditMember').attr('action'),
		type: "POST",
		cache: false,
		data: $('#FormEditMember').serialize(),
		dataType:'json',
		success: function(json){
			if(json.status == 1){
				$('#ResponseInput').html(json.pesan);
				setTimeout(function(){
			   		$('#ResponseInput').html('');
			    }, 3000);
				$('#my-grid').DataTable().ajax.reload( null, false );
			}
			else {
				$('#ResponseInput').html(json.pesan);
			}
		}
	});
}

$(document).ready(function(){
	var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
	Tombol += "<button type='button' class='btn btn-success' id='SimpanEditMember'>Ubah</button>";
	$('#ModalFooter').html(Tombol);

	$('#SimpanEditMember').click(function(e){
		e.preventDefault();
		EditMember();
	});

	$('#FormEditMember').submit(function(e){
		e.preventDefault();
		EditMember();
	});
});
</script>