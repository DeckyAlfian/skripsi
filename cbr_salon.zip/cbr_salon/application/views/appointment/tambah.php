<?php echo form_open('appointment/tambah-appointment', array('id' => 'FormTambahAppointment')); ?>
<div class="form-group row">
    <label for="tanggal" class="col-md-3 col-form-label">Tanggal</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="tanggal" name="tanggal" autocomplete="off" placeholder="yyyy-mm-dd">
    </div>
</div>
<div class="form-group row">
    <label for="jam" class="col-md-3 col-form-label">Jam</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="jam" name="jam" placeholder="hh:mm">
    </div>
</div>
<div class="form-group row">
    <label for="pesan" class="col-md-3 col-form-label">Pesan</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="pesan" name="pesan">
    </div>
</div>

<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
    function TambahAppointment() {
        $.ajax({
            url: $('#FormTambahAppointment').attr('action'),
            type: "POST",
            cache: false,
            data: $('#FormTambahAppointment').serialize(),
            dataType: 'json',
            success: function(json) {
                if (json.status == 1) {
                    $('#ResponseInput').html(json.pesan);
                    setTimeout(function() {
                        $('#ResponseInput').html('');
                    }, 3000);
                    $('#my-grid').DataTable().ajax.reload(null, false);

                    $('#FormTambahAppointment').each(function() {
                        this.reset();
                    });
                } else {
                    $('#ResponseInput').html(json.pesan);
                }
            }
        });
    }

    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        Tombol += "<button type='button' class='btn btn-success' id='SimpanTambahAppointment'>Tambah</button>";
        $('#ModalFooter').html(Tombol);

        $('#SimpanTambahAppointment').click(function(e) {
            e.preventDefault();
            TambahAppointment();
        });

        $('#FormTambahAppointment').submit(function(e) {
            e.preventDefault();
            TambahAppointment();
        });
    });
</script>