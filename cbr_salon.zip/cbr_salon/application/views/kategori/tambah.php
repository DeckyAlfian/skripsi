<?php echo form_open('admin/kategori/tambah-kategori', array('id' => 'FormTambahKategori')); ?>
<div class="form-group row">
    <label for="nama_kategori" class="col-md-3 col-form-label">Nama Kategori</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_kategori" name="nama_kategori">
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
    function TambahKategori() {
        $.ajax({
            url: $('#FormTambahKategori').attr('action'),
            type: "POST",
            cache: false,
            data: $('#FormTambahKategori').serialize(),
            dataType: 'json',
            success: function(json) {
                if (json.status == 1) {
                    $('#ResponseInput').html(json.pesan);
                    setTimeout(function() {
                        $('#ResponseInput').html('');
                    }, 3000);
                    $('#my-grid').DataTable().ajax.reload(null, false);

                    $('#FormTambahKategori').each(function() {
                        this.reset();
                    });
                } else {
                    $('#ResponseInput').html(json.pesan);
                }
            }
        });
    }

    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        Tombol += "<button type='button' class='btn btn-success' id='SimpanTambahKategori'>Tambah</button>";
        $('#ModalFooter').html(Tombol);

        $('#SimpanTambahKategori').click(function(e) {
            e.preventDefault();
            TambahKategori();
        });

        $('#FormTambahKategori').submit(function(e) {
            e.preventDefault();
            TambahKategori();
        });
    });
</script>