<?php echo form_open('admin/kategori/edit-kategori/'.$kategori->id_kategori, array('id' => 'FormEditKategori')); ?>
<div class="form-group row">
    <label for="nama_kategori" class="col-md-3 col-form-label">Nama Kategori</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_kategori" name="nama_kategori" value="<?php echo set_value('nama_kategori', $kategori->nama_kategori); ?>">
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
function EditKategori()
{
	$.ajax({
		url: $('#FormEditKategori').attr('action'),
		type: "POST",
		cache: false,
		data: $('#FormEditKategori').serialize(),
		dataType:'json',
		success: function(json){
			if(json.status == 1){
				$('#ResponseInput').html(json.pesan);
				setTimeout(function(){
			   		$('#ResponseInput').html('');
			    }, 3000);
				$('#my-grid').DataTable().ajax.reload( null, false );
			}
			else {
				$('#ResponseInput').html(json.pesan);
			}
		}
	});
}

$(document).ready(function(){
	var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
	Tombol += "<button type='button' class='btn btn-success' id='SimpanEditKategori'>Ubah</button>";
	$('#ModalFooter').html(Tombol);

	$('#SimpanEditKategori').click(function(e){
		e.preventDefault();
		EditKategori();
	});

	$('#FormEditKategori').submit(function(e){
		e.preventDefault();
		EditKategori();
	});
});
</script>