<?php $this->load->view('template_admin/header'); ?>

<div class="card border-0 shadow">
    <div class="card-body">
        <h4 class="card-title">Riwayat Konsultasi</h4>
        <div class="row">
            <div class="col">
                <div class="d-flex justify-content-center">
                    <span id='notifikasi' style='display: none;'></span>
                </div>
                <div class="table-responsive">
                    <table id="my-grid" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Id Konsultasi</th>
                                <th>Tanggal</th>
                                <th>Member</th>
                                <th>Penyakit</th>
                                <th>Nilai Kedekatan</th>
                                <th>Kasus</th>
                                <th class="no-sort">Aksi</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template_admin/js'); ?>

<script src="<?php echo base_url('assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables/js/dataTables.bootstrap4.min.js'); ?>"></script>
<script>
    $(document).ready(function() {
        var dataTable = $('#my-grid').DataTable({
            "serverSide": true,
            "stateSave": false,
            "bAutoWidth": true,
            "oLanguage": {
                "sEmptyTable": "Tidak ada data",
                "sLoadingRecords": "Harap Tunggu...",
                "oPaginate": {
                    "sPrevious": "Sebelumnya",
                    "sNext": "Selanjutnya"
                }
            },
            "aaSorting": [
                [1, "desc"]
            ],
            "columnDefs": [{
                "targets": 'no-sort',
                "orderable": false,
            }],
            "lengthChange": false,
            "bInfo": false,
            "searching": false,
            "sPaginationType": "simple_numbers",
            "ajax": {
                url: "<?php echo site_url('admin/riwayat/list-riwayat-json'); ?>",
                type: "post",
                error: function() {
                    $(".my-grid-error").html("");
                    $("#my-grid").append('<tbody class="my-grid-error"><tr><th colspan="6">Data tidak ditemukan</th></tr></tbody>');
                    $("#my-grid_processing").css("display", "none");
                }
            }
        });
    });
    $(document).on('click', '#bukti', function(e) {
        e.preventDefault();

        $('#ModalHeader').html('Bukti Transfer');
        $('#ModalContent').load($(this).attr('href'));
        $('#BsModal').modal('show');
    });
</script>

<?php $this->load->view('template_admin/footer'); ?>