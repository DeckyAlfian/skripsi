<?php echo form_open('admin/kasus/tambah-kasus', array('id' => 'FormTambahKasus')); ?>
<div class="form-group row">
    <label for="nama_kasus" class="col-md-3 col-form-label">Nama Kasus</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="nama_kasus" name="nama_kasus">
    </div>
</div>
<?php foreach ($gejala as $t) : ?>
    <div class="form-group row">
        <label for="id_gejala" class="col-md-3 col-form-label"><?php echo $t->nama_gejala; ?></label>
        <div class="col-md-9">
            <select name="id_gejala_<?php echo $t->id_gejala; ?>" id="id_gejala_<?php echo $t->id_gejala; ?>" class="form-control">
                <option value=""></option>
                <?php foreach ($nilai[$t->id_gejala] as $n) : ?>
                    <option value="<?php echo $n->id_nilai; ?>" <?php echo set_select('id_gejala_' . $t->id_gejala, $n->id_nilai); ?>><?php echo $n->nama_nilai; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
<?php endforeach; ?>
<div class="form-group row">
    <label for="id_penyakit" class="col-md-3 col-form-label">Penyakit</label>
    <div class="col-md-9">
        <select name="id_penyakit" id="id_penyakit" class="form-control">
            <option value="">Pilih...</option>
            <?php foreach ($penyakit as $k) : ?>
                <option value="<?php echo $k->id_penyakit; ?>" <?php echo set_select('id_penyakit', $k->id_penyakit); ?>><?php echo $k->nama_penyakit; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
    function TambahKasus() {
        $.ajax({
            url: $('#FormTambahKasus').attr('action'),
            type: "POST",
            cache: false,
            data: $('#FormTambahKasus').serialize(),
            dataType: 'json',
            success: function(json) {
                if (json.status == 1) {
                    $('#ResponseInput').html(json.pesan);
                    setTimeout(function() {
                        $('#ResponseInput').html('');
                    }, 3000);
                    $('#my-grid').DataTable().ajax.reload(null, false);

                    $('#FormTambahKasus').each(function() {
                        this.reset();
                    });
                } else {
                    $('#ResponseInput').html(json.pesan);
                }
            }
        });
    }

    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        Tombol += "<button type='button' class='btn btn-success' id='SimpanTambahKasus'>Tambah</button>";
        $('#ModalFooter').html(Tombol);

        $('#SimpanTambahKasus').click(function(e) {
            e.preventDefault();
            TambahKasus();
        });

        $('#FormTambahKasus').submit(function(e) {
            e.preventDefault();
            TambahKasus();
        });
    });
</script>