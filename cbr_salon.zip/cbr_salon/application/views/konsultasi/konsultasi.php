<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body p-3">
            <h3 class="card-title text-center">Konsultasi</h3>
            <?php if ($this->session->userdata('logged_in') == FALSE) : ?>
                <p>Silahkan <?= anchor('login', 'Login') ?> untuk melakukan konsultasi</p>
            <?php else : ?>
                <p>Silahkan pilih gejala yang dirasakan dengan sebenar-benarnya:</p>
                <form class="mt-4" method="POST" action="<?php echo site_url('konsultasi'); ?>">
                    <?php foreach ($gejala as $t) : ?>
                        <div class="form-group row">
                            <label for="id_gejala" class="col-md-4 col-form-label"><?php echo $t->nama_gejala; ?></label>
                            <div class="col-md-8">
                                <select class="custom-select <?php echo form_error('id_gejala_' . $t->id_gejala) != '' ? 'is-invalid' : ''; ?>" name="id_gejala_<?php echo $t->id_gejala; ?>" id="id_gejala_<?php echo $t->id_gejala; ?>">
                                    <?php foreach ($nilai[$t->id_gejala] as $n) : ?>
                                        <option value="<?php echo $n->id_nilai; ?>" <?php echo set_select('id_gejala_' . $t->id_gejala, $n->id_nilai); ?>><?php echo $n->nama_nilai; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">
                                    <?php echo form_error('id_gejala_' . $t->id_gejala); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div class="d-flex justify-content-end">
                        <button type="reset" class="btn btn-outline-danger mr-2">Reset</button>
                        <button type="submit" name="lanjut" class="btn btn-outline-success">Proses</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>
<?php $this->load->view('template/footer'); ?>