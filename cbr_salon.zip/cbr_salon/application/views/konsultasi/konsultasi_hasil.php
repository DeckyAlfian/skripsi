<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body p-3">
            <h3 class="card-title text-center">Hasil Konsultasi</h3>
            <div class="row">
                <div class="col">
                    <table class="table table-bordered plain">
                        <tr>
                            <td width="200">Penyakit</td>
                            <td><?php echo $hasil->nama_penyakit; ?></td>
                        </tr>
                        <tr>
                            <td width="200">Nilai Kedekatan</td>
                            <td><?php echo $hasil->nilai_kedekatan; ?></td>
                        </tr>
                        <tr>
                            <td width="200">Solusi</td>
                            <td><?php echo $hasil->solusi_penyakit; ?></td>
                        </tr>
                        <tr>
                            <td width="200"></td>
                            <td>
                                <a href="<?php echo site_url('konsultasi/detail/' . $hasil->id_hasil); ?>" class="btn btn-outline-info btn-sm mr-1" id="DetailHasil" title="Lihat Detail Perhitungan">Detail Perhitungan</a>
                                <a href="<?php echo site_url('konsultasi'); ?>" class="btn btn-outline-secondary btn-sm">Ulangi Konsultasi</a>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>

<script>
    $(document).on('click', '#DetailHasil', function(e) {
        e.preventDefault();

        $('.modal-dialog').removeClass('modal-md');
        $('.modal-dialog').addClass('modal-lg');
        if ($(this).attr('id') == 'DetailHasil') {
            $('#ModalHeader').html('Detail Hasil Perhitungan');
        }
        $('#ModalContent').load($(this).attr('href'));
        $('#BsModal').modal('show');
    });
</script>

<?php $this->load->view('template/footer'); ?>