<?php $this->load->view('template/header'); ?>

<div class="container">
    <div class="card border-0 shadow my-2">
        <div class="card-body p-3">
            <h3 class="card-title text-center">Hasil Konsultasi</h3>
            <div class="row">
                <div class="col">
                    <p>Untuk melihat hasil konsultasi, silahkan transfer sejumlah <strong>Rp. 25.000</strong> ke nomor rekening dibawah ini:</p>
                    <p>Atas Nama</p>
                    <p>Bank Mandiri</p>
                    <p>123456789123</p>
                    <a href="<?php echo site_url('konsultasi'); ?>" class="btn btn-outline-secondary btn-sm">Konsultasi Lagi</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('template/js'); ?>
<?php $this->load->view('template/footer'); ?>