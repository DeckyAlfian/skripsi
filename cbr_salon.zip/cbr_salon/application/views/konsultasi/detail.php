<div class="row">
    <div class="col">
        <table class="table table-bordered plain">
            <tr>
                <td><?php echo $result; ?></td>
            </tr>
        </table>
    </div>
</div>

<script>
    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        $('#ModalFooter').html(Tombol);
    });
</script>