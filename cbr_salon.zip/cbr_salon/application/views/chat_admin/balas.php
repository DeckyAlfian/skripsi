<?php echo form_open('admin/chat/balas-chat/' . $chat->id_chat, array('id' => 'FormBalasChat')); ?>
<table class="table table-striped table-bordered">
    <tr>
        <td><b>Judul</b></td>
        <td><b><?php echo $chat->judul; ?></b></td>
    </tr>
    <tr>
        <td><b>Member</b></td>
        <td><b><?php echo $chat->nama; ?></b></td>
    </tr>
</table>
<table class="table table-striped table-bordered">
    <?php foreach ($chat_detail as $row) : ?>
        <tr>
            <td>
                <?php if ($row->oleh == 'Member') : ?>
                    <span class="text-success"><?php echo $chat->nama; ?></span> <small class="text-muted"><?php echo date('d-m-Y H:i', strtotime($row->waktu)); ?></small>
                <?php else : ?>
                    <span class="text-primary">Admin</span> <small class="text-muted"><?php echo date('d-m-Y H:i', strtotime($row->waktu)); ?></small>
                <?php endif; ?>
                <p><?php echo $row->pesan; ?></p>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<div class="form-group row">
    <label for="pesan" class="col-md-3 col-form-label">Balas Pesan</label>
    <div class="col-md-9">
        <textarea class="form-control" id="pesan" name="pesan" rows="3"></textarea>
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
    function BalasChat() {
        $.ajax({
            url: $('#FormBalasChat').attr('action'),
            type: "POST",
            cache: false,
            data: $('#FormBalasChat').serialize(),
            dataType: 'json',
            success: function(json) {
                if (json.status == 1) {
                    $('#ResponseInput').html(json.pesan);
                    setTimeout(function() {
                        $('#ResponseInput').html('');
                    }, 3000);
                    $('#my-grid').DataTable().ajax.reload(null, false);
                } else {
                    $('#ResponseInput').html(json.pesan);
                }
            }
        });
    }

    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        Tombol += "<button type='button' class='btn btn-success' id='SimpanBalasChat'>Kirim</button>";
        $('#ModalFooter').html(Tombol);

        $('#SimpanBalasChat').click(function(e) {
            e.preventDefault();
            BalasChat();
        });

        $('#FormBalasChat').submit(function(e) {
            e.preventDefault();
            BalasChat();
        });
    });
</script>