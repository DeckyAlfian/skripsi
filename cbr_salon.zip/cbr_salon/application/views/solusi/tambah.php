<?php echo form_open('admin/solusi/tambah-solusi', array('id' => 'FormTambahSolusi')); ?>
<div class="form-group row">
    <label for="id_penyakit" class="col-md-3 col-form-label">Nama Penyakit</label>
    <div class="col-md-9">
        <select name="id_penyakit" id="id_penyakit" class="form-control">
            <option value="">Pilih...</option>
            <?php foreach($penyakit as $k): ?>
                <option value="<?php echo $k->id_penyakit; ?>"><?php echo $k->nama_penyakit; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<div class="form-group row">
    <label for="solusi_penyakit" class="col-md-3 col-form-label">Solusi</label>
    <div class="col-md-9">
        <textarea class="form-control" id="solusi_penyakit" name="solusi_penyakit" rows="6"></textarea>
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
    function TambahSolusi() {
        $.ajax({
            url: $('#FormTambahSolusi').attr('action'),
            type: "POST",
            cache: false,
            data: $('#FormTambahSolusi').serialize(),
            dataType: 'json',
            success: function(json) {
                if (json.status == 1) {
                    $('#ResponseInput').html(json.pesan);
                    setTimeout(function() {
                        $('#ResponseInput').html('');
                    }, 3000);
                    $('#my-grid').DataTable().ajax.reload(null, false);

                    $('#FormTambahSolusi').each(function() {
                        this.reset();
                    });
                } else {
                    $('#ResponseInput').html(json.pesan);
                }
            }
        });
    }

    $(document).ready(function() {
        var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
        Tombol += "<button type='button' class='btn btn-success' id='SimpanTambahSolusi'>Tambah</button>";
        $('#ModalFooter').html(Tombol);

        $('#SimpanTambahSolusi').click(function(e) {
            e.preventDefault();
            TambahSolusi();
        });

        $('#FormTambahSolusi').submit(function(e) {
            e.preventDefault();
            TambahSolusi();
        });
    });
</script>