<?php echo form_open('admin/appointment/balas-appointment/'.$appointment->id_appointment, array('id' => 'FormBalasAppointment')); ?>
<div class="form-group row">
    <label for="status" class="col-md-3 col-form-label">Status</label>
    <div class="col-md-9">
        <select class="form-control" name="status" id="status">
            <option value="">Pilih...</option>
            <option value="Menunggu" <?php echo set_select('status', 'Menunggu', $appointment->status == 'Menunggu' ? TRUE : FALSE); ?>>Menunggu</option>
            <option value="Disetujui" <?php echo set_select('status', 'Disetujui', $appointment->status == 'Disetujui' ? TRUE : FALSE); ?>>Disetujui</option>
            <option value="Ditolak" <?php echo set_select('status', 'Ditolak', $appointment->status == 'Ditolak' ? TRUE : FALSE); ?>>Ditolak</option>
        </select>
    </div>
</div>
<div class="form-group row">
    <label for="keterangan" class="col-md-3 col-form-label">Keterangan</label>
    <div class="col-md-9">
        <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?php echo set_value('keterangan', $appointment->keterangan); ?>">
    </div>
</div>
<?php echo form_close(); ?>

<div id='ResponseInput'></div>

<script>
function BalasAppointment()
{
	$.ajax({
		url: $('#FormBalasAppointment').attr('action'),
		type: "POST",
		cache: false,
		data: $('#FormBalasAppointment').serialize(),
		dataType:'json',
		success: function(json){
			if(json.status == 1){
				$('#ResponseInput').html(json.pesan);
				setTimeout(function(){
			   		$('#ResponseInput').html('');
			    }, 3000);
				$('#my-grid').DataTable().ajax.reload( null, false );
			}
			else {
				$('#ResponseInput').html(json.pesan);
			}
		}
	});
}

$(document).ready(function(){
	var Tombol = "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Tutup</button>";
	Tombol += "<button type='button' class='btn btn-success' id='SimpanBalasAppointment'>Simpan</button>";
	$('#ModalFooter').html(Tombol);

	$('#SimpanBalasAppointment').click(function(e){
		e.preventDefault();
		BalasAppointment();
	});

	$('#FormBalasAppointment').submit(function(e){
		e.preventDefault();
		BalasAppointment();
	});
});
</script>