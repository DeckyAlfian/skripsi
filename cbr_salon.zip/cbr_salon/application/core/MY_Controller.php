<?php
class MY_Controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function input_error()
	{
		$json['status'] = 0;
        $json['pesan'] 	= "<div class='alert alert-warning error_validasi'>".validation_errors()."</div>";
		echo json_encode($json);
	}

	function query_error($pesan = "Terjadi kesalahan, coba lagi !")
	{
		$json['status'] = 2;
		$json['pesan'] 	= "<div class='alert alert-danger error_validasi'>".$pesan."</div>";
		echo json_encode($json);
	}

}