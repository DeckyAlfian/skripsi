<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Appointment extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('appointment/data');
    }

    public function list_appointment_json()
    {
        $this->load->model('appointment_model');

        $requestData = $_REQUEST;

        if ($this->session->userdata('level') == 'Member'){
            $this->load->model('member_model');
            $member = $this->member_model->get_baris_by_id_pengguna($this->session->userdata('id_pengguna'))->row_array();
            $id_member = $member['id_member'];
            $fetch = $this->appointment_model->fetch_data_member($id_member, $requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);
        }else{
            $fetch = $this->appointment_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);
        }

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama'];
            $nestedData[] = $row['tanggal'];
            $nestedData[] = date('H:i', strtotime($row['jam']));
            $nestedData[] = $row['pesan'];
            $nestedData[] = $row['status'];
            $nestedData[] = $row['keterangan'];
            if ($this->session->userdata('level') == "Admin"){
                $nestedData[] = "<a href='" . site_url('appointment/balas-appointment/' . $row['id_appointment']) . "' id='BalasAppointment' class='text-success font-weight-bold'>Balas</a>";
            }else{
                $nestedData[] = "<a href='" . site_url('appointment/hapus-appointment/' . $row['id_appointment']) . "' id='HapusAppointment' class='text-danger font-weight-bold'>Hapus</a>";
            }
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_appointment()
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
                $this->form_validation->set_rules('jam', 'Jam', 'required');
                $this->form_validation->set_rules('pesan', 'Pesan', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $this->load->model('appointment_model');
                    $this->load->model('member_model');
                    $member = $this->member_model->get_baris_by_id_pengguna($this->session->userdata('id_pengguna'))->row_array();
                    $id_member = $member['id_member'];
                    $tanggal = $this->input->post('tanggal');
                    $jam = $this->input->post('jam');
                    $pesan = $this->input->post('pesan');
                    $status = 'Menunggu';
                    $dt = array(
                        'id_member' => $id_member,
                        'tanggal' => $tanggal,
                        'jam' => $jam,
                        'pesan' => $pesan,
                        'status' => $status,
                    );
                    $insert = $this->appointment_model->tambah_appointment($dt);
                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->view('appointment/tambah');
            }
        }
    }

    public function hapus_appointment($id_appointment)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('appointment_model');
            $hapus = $this->appointment_model->hapus_appointment($id_appointment);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function balas_appointment($id_appointment = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('appointment_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('status', 'Status', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $status = $this->input->post('status');
                    $keterangan = $this->input->post('keterangan');
                    $dt = array(
                        'status' => $status,
                        'keterangan' => $keterangan,
                    );
                    $update = $this->appointment_model->update_appointment($id_appointment, $dt);
                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil disimpan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $data['appointment'] = $this->appointment_model->get_baris($id_appointment)->row();
                $this->load->view('appointment/balas', $data);
            }
        }
    }

}

/* End of file Appointment.php */
/* Location: ./application/controllers/Appointment.php */
