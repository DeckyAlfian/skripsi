<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Konsultasi extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $this->konsultasi();
    }

    public function konsultasi()
    {
        $this->load->model('konsultasi_model');
        $this->load->model('penyakit_model');
        $this->load->model('gejala_model');
        $this->load->model('nilai_model');
        $data['penyakit'] = $this->penyakit_model->get_all()->result();
        $data['gejala'] = $this->gejala_model->get_all()->result();
        foreach ($data['gejala'] as $gejala) {
            $data['nilai'][$gejala->id_gejala] = $this->nilai_model->get_all($gejala->id_gejala)->result();
        }

        $this->load->library('form_validation');

        foreach ($data['gejala'] as $gejala) {
            $this->form_validation->set_rules('id_gejala_' . $gejala->id_gejala, $gejala->nama_gejala, 'required');
        }

        $this->form_validation->set_message('required', '%s harus diisi !');

        if ($this->form_validation->run()) {
            $tanggal = date('Y-m-d');
            $id_member = NULL;
            if ($this->session->userdata('level') == "Member"){
                $this->load->model('member_model');
                $member = $this->member_model->get_baris_by_id_pengguna($this->session->userdata('id_pengguna'))->row_array();
                $id_member = $member['id_member'];
            }
            $params = array(
                'tanggal' => $tanggal,
                'id_member' => $id_member,
            );
            $id_konsultasi = $this->konsultasi_model->tambah_konsultasi($params);

            foreach ($data['gejala'] as $gejala) {
                $id_nilai = $this->input->post('id_gejala_' . $gejala->id_gejala);
                $dt = array(
                    'id_konsultasi' => $id_konsultasi,
                    'id_gejala' => $gejala->id_gejala,
                    'id_nilai' => $id_nilai,
                );
                $this->konsultasi_model->tambah_konsultasi_gejala($dt);
            }

            // panggil metode CBR untuk menghitung nilai kedekatan
            $hasil = $this->get_nilai_kedekatan($id_konsultasi);
            $params_hasil = array(
                'id_konsultasi' => $id_konsultasi,
                'id_penyakit' => $hasil['id_penyakit'],
                'nilai_kedekatan' => $hasil['nilai_kedekatan'],
                'id_kasus' => $hasil['id_kasus'],
            );
            $this->load->model('hasil_model');
            $this->hasil_model->tambah_hasil($params_hasil);
            // ---

            redirect('konsultasi?a=hasil&id=' . $id_konsultasi);
        } else {
            $act = $this->input->get('a', TRUE);
            if ($act == 'hasil') {
                // $id_konsultasi = $this->input->get('id', TRUE);
                // $this->load->model('hasil_model');
                // $data['hasil'] = $this->hasil_model->get_hasil($id_konsultasi)->row();
                // $this->load->view('konsultasi/konsultasi_hasil', $data);
                $this->load->view('konsultasi/konsultasi_hasil_bayar');
            } else {
                $this->load->view('konsultasi/konsultasi', $data);
            }
        }
    }

    public function detail($id_hasil = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('hasil_model');
            $hasil = $this->hasil_model->get_baris($id_hasil)->row();
            $data['result'] = $this->tampil_nilai_kedekatan($hasil->id_konsultasi, $hasil->id_kasus);
            $this->load->view('konsultasi/detail', $data);
        }
    }


    // --- metode CBR ---
    public function get_nilai_kedekatan($id_konsultasi)
    {
        $this->load->model('nilai_model');
        $this->load->model('gejala_model');

        $kasus = $this->get_kasus();
        $konsultasi = $this->get_konsultasi($id_konsultasi);

        $hasil = array();
        foreach ($kasus as $kl) {
            $total_bobot_kedekatan = 0;
            $total_bobot = 0;
            foreach ($kl['gejala'] as $t) {
                foreach ($konsultasi['gejala'] as $tb) {
                    if ($tb['id_gejala'] == $t['id_gejala']) {
                        $res = $this->nilai_model->get_nilai_kedekatan($t['id_gejala'], $tb['id_nilai'], $t['id_nilai'])->row_array();
                        $nilai_kedekatan = empty($res['nilai_kedekatan']) ? 0 : $res['nilai_kedekatan'];
                        $gejala = $this->gejala_model->get_baris($tb['id_gejala'])->row_array();
                        $total_bobot_kedekatan += ($nilai_kedekatan * $gejala['bobot']);
                        $total_bobot += $gejala['bobot'];
                    }
                }
            }
            $nilai_cbr = $total_bobot_kedekatan / $total_bobot;
            $hasil[] = array(
                "id_kasus" => $kl['id_kasus'],
                "id_penyakit" => $kl['id_penyakit'],
                "nilai_kedekatan" => $nilai_cbr,
            );
        }

        // urutkan berdasarkan nilai terbesar
        $this->array_sort_by_column($hasil, 'nilai_kedekatan');

        return $hasil[0];
    }

    public function get_kasus()
    {
        $this->load->model('kasus_model');
        $this->load->model('gejala_model');
        $this->load->model('nilai_model');

        $kasus = $this->kasus_model->get_all()->result_array();
        $gejala = $this->gejala_model->get_all()->result_array();

        $arr = array();
        foreach ($kasus as $kl) {
            $val = array(
                "id_kasus" => $kl['id_kasus'],
                "id_penyakit" => $kl['id_penyakit'],
                "gejala" => array(),
            );
            foreach ($gejala as $t) {
                $klt = $this->kasus_model->get_kasus_gejala($kl['id_kasus'], $t['id_gejala'])->row_array();
                $id_nilai = empty($klt['id_nilai']) ? '' : $klt['id_nilai'];
                $val['gejala'][] = array(
                    "id_gejala" => $t['id_gejala'],
                    "id_nilai" => $id_nilai,
                );
            }
            $arr[] = $val;
        }
        return $arr;
    }

    public function get_konsultasi($id_konsultasi)
    {
        $this->load->model('gejala_model');
        $this->load->model('konsultasi_model');

        $gejala = $this->gejala_model->get_all()->result_array();

        $val = array(
            "id_konsultasi" => $id_konsultasi,
            "gejala" => array(),
        );
        foreach ($gejala as $t) {
            $klt = $this->konsultasi_model->get_konsultasi_gejala($id_konsultasi, $t['id_gejala'])->row_array();
            $id_nilai = empty($klt['id_nilai']) ? '' : $klt['id_nilai'];
            $val['gejala'][] = array(
                "id_gejala" => $t['id_gejala'],
                "id_nilai" => $id_nilai,
            );
        }
        return $val;
    }

    public function array_sort_by_column(&$arr, $col, $dir = SORT_DESC)
    {
        $sort_col = array();
        foreach ($arr as $key => $row) {
            $sort_col[$key] = $row[$col];
        }
        return array_multisort($sort_col, $dir, $arr);
    }

    // --- untuk menampilkan detail perhitungan

    public function get_kasus_row($id_kasus)
    {
        $this->load->model('gejala_model');
        $this->load->model('kasus_model');

        $gejala = $this->gejala_model->get_all()->result_array();

        $val = array(
            "id_kasus" => $id_kasus,
            "gejala" => array(),
        );
        foreach ($gejala as $t) {
            $klt = $this->kasus_model->get_kasus_gejala($id_kasus, $t['id_gejala'])->row_array();
            $id_nilai = empty($klt['id_nilai']) ? '' : $klt['id_nilai'];
            $val['gejala'][] = array(
                "id_gejala" => $t['id_gejala'],
                "id_nilai" => $id_nilai,
            );
        }
        return $val;
    }

    public function tampil_nilai_kedekatan($id_konsultasi, $id_kasus)
    {
        $this->load->model('nilai_model');
        $this->load->model('gejala_model');

        $kasus = $this->get_kasus_row($id_kasus);
        $konsultasi = $this->get_konsultasi($id_konsultasi);

        $total_bobot_kedekatan = 0;
        $total_bobot = 0;
        $result = '';
        $temp = array();
        $temp2 = array();
        $temp3 = array();
        foreach ($kasus['gejala'] as $t) {
            foreach ($konsultasi['gejala'] as $tb) {
                if ($tb['id_gejala'] == $t['id_gejala']) {
                    $res = $this->nilai_model->get_nilai_kedekatan($t['id_gejala'], $tb['id_nilai'], $t['id_nilai'])->row_array();
                    $nilai_kedekatan = empty($res['nilai_kedekatan']) ? 0 : $res['nilai_kedekatan'];
                    $gejala = $this->gejala_model->get_baris($tb['id_gejala'])->row_array();
                    $total_bobot_kedekatan += ($nilai_kedekatan * $gejala['bobot']);
                    $total_bobot += $gejala['bobot'];
                    $temp[] = '(' . floatval($nilai_kedekatan) . ' x ' . $gejala['bobot'] . ')';
                    $temp2[] = $gejala['bobot'];
                    $temp3[] = $nilai_kedekatan * $gejala['bobot'];
                }
            }
        }
        $string_temp = implode(' + ', $temp);
        $string_temp2 = implode(' + ', $temp2);
        $string_temp3 = implode(' + ', $temp3);
        $result .= '= (' . $string_temp . ') / (' . $string_temp2 . ')<br>';
        $result .= '= (' . $string_temp3 . ') / ' . $total_bobot . '<br>';
        $nilai_cbr = $total_bobot_kedekatan / $total_bobot;
        $result .= '= ' . $total_bobot_kedekatan . ' / ' . $total_bobot . '<br>';
        $result .= '= <b>' . floatval($nilai_cbr) . '</b><br>';

        return $result;
    }

    // ---

    // ---

}


/* End of file Konsultasi.php */
/* Location: ./application/controllers/Konsultasi.php */
