<?php
defined('BASEPATH') or exit('No direct script access allowed');

use Dompdf\Dompdf;

class Frontend extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $this->home();
    }

    public function home()
    {
        if ($this->session->userdata('level') == "Admin") {
            redirect('admin/home');
        }
        $this->load->view('frontend/home');
    }

    public function daftar_penyakit()
    {
        if ($this->session->userdata('level') == "Admin") {
            redirect('admin/home');
        }
        $this->load->view('frontend/penyakit');
    }

    public function informasi_solusi()
    {
        if ($this->session->userdata('level') == "Admin") {
            redirect('admin/home');
        }
        $this->load->view('frontend/solusi');
    }

    public function hasil_konsultasi()
    {
        if ($this->session->userdata('level') == "Admin") {
            redirect('admin/home');
        }
        $this->load->view('frontend/hasil');
    }

    public function acc($id_hasil)
    {
        $dt = array(
            'acc' => TRUE,
        );
        $this->load->model('hasil_model');
        $this->hasil_model->update_hasil($id_hasil, $dt);
        redirect('admin/riwayat');
    }

    public function bukti_transfer($id_hasil)
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('userfile', 'Bukti Transfer', 'callback_validasi_foto');

        if ($this->form_validation->run()) {
            $upload = $this->upload->data();
            $file_name = $upload['file_name'];
            $dt = array(
                'bayar' => TRUE,
                'notif' => TRUE,
                'bukti_transfer' => $file_name,
            );
            $this->load->model('hasil_model');
            $update = $this->hasil_model->update_hasil($id_hasil, $dt);
            if ($update) {
                redirect('hasil-konsultasi');
            }
        } else {
            $data['id_hasil'] = $id_hasil;
            $this->load->view('frontend/transfer', $data);
        }
    }

    public function validasi_foto()
    {
        $config['upload_path'] = './assets/images/bukti_transfer/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['overwrite'] = FALSE;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload()) {
            return TRUE;
        } else {
            $this->form_validation->set_message('validasi_foto', $this->upload->display_errors());
            return FALSE;
        }
    }

    public function list_penyakit_json()
    {
        $this->load->model('penyakit_model');

        $requestData = $_REQUEST;
        $fetch = $this->penyakit_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['kode_penyakit'];
            $nestedData[] = $row['nama_penyakit'];
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function list_solusi_json()
    {
        $this->load->model('solusi_model');

        $requestData = $_REQUEST;
        $fetch = $this->solusi_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama_penyakit'];
            $nestedData[] = $row['solusi_penyakit'];
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function list_hasil_json()
    {
        $this->load->model('hasil_model');

        $requestData = $_REQUEST;

        if ($this->session->userdata('level') == 'Member') {
            $this->load->model('member_model');
            $member = $this->member_model->get_baris_by_id_pengguna($this->session->userdata('id_pengguna'))->row_array();
            $id_member = $member['id_member'];
            $fetch = $this->hasil_model->fetch_data_member($id_member, $requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);
        } else {
            $fetch = $this->hasil_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);
        }

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $hsl = '';
            if ($row['acc'] == TRUE) {
                $hsl = $row['nama_penyakit'];
            } else {
                $hsl = $row['bayar'] == TRUE ? '<span class="badge badge-success">Menunggu Verifikasi Admin</span>' : '<a href="#" class="btn btn-outline-danger btn-sm mr-1" id="bayar" title="Lihat Informasi Pembayaran">Belum Bayar</a><a href="' . site_url('bukti-transfer/' . $row['id_hasil']) . '" class="btn btn-outline-success btn-sm" id="upload" title="Upload Bukti Transfer">Bukti Transfer</a>';
            }
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['id_konsultasi'];
            $nestedData[] = $row['tanggal'];
            $nestedData[] = empty($row['nama']) ? 'Non Member' : $row['nama'];
            $nestedData[] = $hsl;
            $nestedData[] = $row['acc'] == TRUE ? '<a href="' . site_url('cetak/' . $row['id_konsultasi']) . '" target="_blank" class="btn btn-outline-info btn-sm" title="Cetak">Cetak</a>' : '';
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function registrasi()
    {
        if ($this->session->userdata('logged_in')) {
            redirect('home');
        }

        if ($this->session->userdata('level') == "Admin") {
            redirect('admin/home');
        }

        $this->load->library('form_validation');
        $this->load->model('pengguna_model');
        $this->load->model('member_model');

        $this->form_validation->set_rules('nama', 'Nama', 'required', array('required' => "Isi dulu %s",));
        $this->form_validation->set_rules('alamat', 'Alamat', 'required', array('required' => "Isi dulu %s",));
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required', array('required' => "Isi dulu %s",));
        $this->form_validation->set_rules('no_hp', 'No HP', 'required|numeric', array('required' => "Isi dulu %s", 'numeric' => "%s harus angka",));
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[pengguna.username]', array('required' => "Isi dulu %s", 'is_unique' => "%s sudah digunakan",));
        $this->form_validation->set_rules('password', 'Password', 'required', array('required' => "Isi dulu %s",));
        $this->form_validation->set_rules('confirm_password', 'Ulangi Password', 'required|matches[password]', array('required' => "Isi dulu %s", 'matches' => "%s tidak sama",));

        if ($this->form_validation->run()) {
            $params = array(
                'nama_lengkap' => $this->input->post('nama', TRUE),
                'username' => $this->input->post('username', TRUE),
                'password' => password_hash($this->input->post('confirm_password', TRUE), PASSWORD_DEFAULT),
                'akses_level' => 'Member',
            );
            $id_pengguna = $this->pengguna_model->add_pengguna($params);

            $params2 = array(
                'nama' => $this->input->post('nama', TRUE),
                'alamat' => $this->input->post('alamat', TRUE),
                'jenis_kelamin' => $this->input->post('jenis_kelamin', TRUE),
                'no_hp' => $this->input->post('no_hp', TRUE),
                'id_pengguna' => $id_pengguna,
            );
            $this->member_model->tambah_member($params2);

            $this->session->set_flashdata('success', '<div class="alert alert-success" role="alert">Proses pendaftaran member berhasil, anda sudah bisa login</div>');
            redirect('registrasi');
        } else {
            $this->load->view('frontend/registrasi');
        }
    }

    public function login()
    {
        if ($this->session->userdata('level') == "Admin") {
            redirect('admin/home');
        }
        if ($this->session->userdata('logged_in')) {
            redirect('home');
        }

        $this->load->library('form_validation');
        $this->load->model('pengguna_model');

        $this->form_validation->set_rules('username', 'Username', 'required', array('required' => "Isi dulu %s",));
        $this->form_validation->set_rules('password', 'Password', 'required', array('required' => "Isi dulu %s",));

        if ($this->form_validation->run()) {
            $username = $this->input->post('username', TRUE);
            $password = $this->input->post('password', TRUE);
            $query = $this->pengguna_model->get_by_username($username);
            if ($query->num_rows() > 0) {
                $result = $query->row_array();
                if (password_verify($password, $result['password'])) {
                    $session_data = array(
                        'id_pengguna' => $result['id_pengguna'],
                        'nama_lengkap' => $result['nama_lengkap'],
                        'level' => $result['akses_level'],
                        'logged_in' => TRUE,
                    );
                    $this->session->set_userdata($session_data);
                    if ($result['akses_level'] == 'Admin') {
                        redirect('admin/home');
                    } else {
                        redirect('home');
                    }
                } else {
                    $this->session->set_flashdata('error', '<div class="alert alert-danger text-center" role="alert">Username dan Password salah</div>');
                    redirect('login');
                }
            } else {
                $this->session->set_flashdata('error', '<div class="alert alert-danger text-center" role="alert">Username dan Password salah</div>');
                redirect('login');
            }
        } else {
            $this->load->view('login');
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }

    public function password()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }

        if ($this->session->userdata('level') == "Admin") {
            redirect('admin/home');
        }

        $this->load->library('form_validation');

        $this->form_validation->set_rules('password_lama', 'Password Lama', 'trim|required|callback_cek_password_lama');
        $this->form_validation->set_rules('password_baru', 'Password Baru', 'trim|required');
        $this->form_validation->set_rules('ulangi_password', 'Ulangi Password Baru', 'trim|required|matches[password_baru]');

        $this->form_validation->set_message('required', '%s harus diisi !');
        $this->form_validation->set_message('matches', '%s tidak sama !');

        if ($this->form_validation->run()) {
            $this->load->model('pengguna_model');
            $params = array(
                'password' => password_hash($this->input->post('ulangi_password', TRUE), PASSWORD_DEFAULT),
            );
            $this->pengguna_model->update_pengguna($this->session->userdata('id_pengguna'), $params);
            $this->session->set_flashdata('success', '<div class="alert alert-success" role="alert">Password berhasil diubah</div>');
            redirect('password');
        } else {
            $this->load->view('password');
        }
    }

    public function cek_password_lama($password)
    {
        $this->load->model('pengguna_model');
        if ($password != '') {
            $pengguna = $this->pengguna_model->get_pengguna($this->session->userdata('id_pengguna'))->row_array();
            if (password_verify($password, $pengguna['password'])) {
                return TRUE;
            } else {
                $this->form_validation->set_message('cek_password_lama', '{field} salah');
                return FALSE;
            }
        }
    }

    public function lihat_bukti_transfer($id_hasil = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('hasil_model');
            $hasil = $this->hasil_model->get_baris($id_hasil)->row();
            $data['result'] = '<img src="' . base_url('assets/images/bukti_transfer/' . $hasil->bukti_transfer) . '" alt="Bukti Transfer">';
            $this->load->view('konsultasi/detail', $data);
        }
    }

    public function cetak($id_konsultasi)
    {
        $this->load->model('hasil_model');
        $data['hasil'] = $this->hasil_model->get_hasil($id_konsultasi)->row();
        $html = $this->load->view('frontend/cetak', $data, TRUE);

        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream("laporan-hasil-konsultasi.pdf", array("Attachment" => FALSE));
    }
}


/* End of file Frontend.php */
/* Location: ./application/controllers/Frontend.php */
