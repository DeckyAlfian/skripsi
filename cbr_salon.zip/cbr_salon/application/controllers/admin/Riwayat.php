<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Riwayat extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $dt = array(
            'notif' => FALSE,
        );
        $this->load->model('hasil_model');
        $this->hasil_model->update_notif($dt);
        $this->load->view('riwayat/data');
    }

    public function list_riwayat_json()
    {
        $this->load->model('hasil_model');

        $requestData = $_REQUEST;
        $fetch = $this->hasil_model->fetch_data_riwayat($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $acc = $row['acc'] == FALSE ? '<a href="' . site_url('acc/' . $row['id_hasil']) . '" class="btn btn-outline-success btn-sm" title="Acc">ACC</a>' : '';
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['id_konsultasi'];
            $nestedData[] = $row['tanggal'];
            $nestedData[] = empty($row['nama']) ? 'Non Member' : $row['nama'];
            $nestedData[] = $row['nama_penyakit'];
            $nestedData[] = $row['nilai_kedekatan'];
            $nestedData[] = $row['nama_kasus'];
            $nestedData[] = $row['bukti_transfer'] == '' ? '<span class="badge badge-danger">Belum Bayar</span>' : '<a href="' . site_url('bukti-transfer/lihat/' . $row['id_hasil']) . '" class="btn btn-outline-info btn-sm mr-1" id="bukti" title="Lihat Bukti Transfer">Bukti Transfer</a>' . $acc;
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }
}


/* End of file Riwayat.php */
/* Location: ./application/controllers/Riwayat.php */
