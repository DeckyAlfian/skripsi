<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Gejala extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('gejala/data');
    }

    public function list_gejala_json()
    {
        $this->load->model('gejala_model');

        $requestData = $_REQUEST;
        $fetch = $this->gejala_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['kode_gejala'];
            $nestedData[] = $row['nama_gejala'];
            $nestedData[] = $row['bobot'];
            $nestedData[] = $row['nama_kategori'];
            $nestedData[] = "<a href='" . site_url('admin/gejala/hapus-gejala/' . $row['id_gejala']) . "' id='HapusGejala' class='text-danger font-weight-bold'>Hapus</a> |
            <a href='" . site_url('admin/gejala/edit-gejala/' . $row['id_gejala']) . "' id='EditGejala' class='text-success font-weight-bold'>Ubah</a> |
            <a href='" . site_url('admin/gejala/nilai-gejala/' . $row['id_gejala']) . "' class='text-info font-weight-bold'>Nilai</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_gejala()
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('kode_gejala', 'Kode Gejala', 'trim|required|is_unique[gejala.kode_gejala]');
                $this->form_validation->set_rules('nama_gejala', 'Nama Gejala', 'trim|required');
                $this->form_validation->set_rules('bobot', 'Bobot', 'trim|required|numeric');
                $this->form_validation->set_rules('id_kategori', 'Kategori', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');
                $this->form_validation->set_message('numeric', '%s harus angka !');
                $this->form_validation->set_message('is_unique', '%s sudah digunakan !');

                if ($this->form_validation->run()) {
                    $this->load->model('gejala_model');
                    $kode_gejala = $this->input->post('kode_gejala');
                    $nama_gejala = $this->input->post('nama_gejala');
                    $bobot = $this->input->post('bobot');
                    $id_kategori = $this->input->post('id_kategori');
                    $dt = array(
                        'kode_gejala' => $kode_gejala,
                        'nama_gejala' => $nama_gejala,
                        'bobot' => $bobot,
                        'id_kategori' => $id_kategori,
                    );
                    $insert = $this->gejala_model->tambah_gejala($dt);
                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->model('kategori_model');
                $data['kategori'] = $this->kategori_model->get_all()->result();
                $this->load->view('gejala/tambah', $data);
            }
        }
    }

    public function hapus_gejala($id_gejala)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('gejala_model');
            $hapus = $this->gejala_model->hapus_gejala($id_gejala);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function edit_gejala($id_gejala = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('gejala_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('kode_gejala', 'Kode Gejala', 'trim|required|callback_cek_kode_gejala');
                $this->form_validation->set_rules('nama_gejala', 'Nama Gejala', 'trim|required');
                $this->form_validation->set_rules('bobot', 'Bobot', 'trim|required|numeric');
                $this->form_validation->set_rules('id_kategori', 'Kategori', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');
                $this->form_validation->set_message('numeric', '%s harus angka !');

                if ($this->form_validation->run()) {
                    $kode_gejala = $this->input->post('kode_gejala');
                    $nama_gejala = $this->input->post('nama_gejala');
                    $bobot = $this->input->post('bobot');
                    $id_kategori = $this->input->post('id_kategori');
                    $dt = array(
                        'kode_gejala' => $kode_gejala,
                        'nama_gejala' => $nama_gejala,
                        'bobot' => $bobot,
                        'id_kategori' => $id_kategori,
                    );
                    $update = $this->gejala_model->update_gejala($id_gejala, $dt);
                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil diubah</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->model('kategori_model');
                $data['kategori'] = $this->kategori_model->get_all()->result();
                $data['gejala'] = $this->gejala_model->get_baris($id_gejala)->row();
                $this->load->view('gejala/edit', $data);
            }
        }
    }

    public function nilai_gejala($id_gejala)
    {
        $this->load->model('gejala_model');
        $data['id_gejala'] = $id_gejala;
        $data['gejala'] = $this->gejala_model->get_baris($id_gejala)->row();
        $this->load->view('gejala/data_nilai', $data);
    }

    public function list_gejala_nilai_json($id_gejala)
    {
        $this->load->model('nilai_model');

        $requestData = $_REQUEST;
        $fetch = $this->nilai_model->fetch_data($id_gejala, $requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama_nilai'];
            $nestedData[] = "<a href='" . site_url('admin/gejala/hapus-gejala-nilai/' . $row['id_nilai']) . "' id='HapusGejalaNilai' class='text-danger font-weight-bold'>Hapus</a> |
            <a href='" . site_url('admin/gejala/edit-gejala-nilai/' . $row['id_nilai']) . "' id='EditGejalaNilai' class='text-success font-weight-bold'>Ubah</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_gejala_nilai($id_gejala)
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama_nilai', 'Nama Nilai', 'trim|required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $this->load->model('nilai_model');
                    $nama_nilai = $this->input->post('nama_nilai');
                    $dt = array(
                        'id_gejala' => $id_gejala,
                        'nama_nilai' => $nama_nilai,
                    );
                    $insert = $this->nilai_model->tambah_gejala_nilai($dt);
                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $data['id_gejala'] = $id_gejala;
                $this->load->view('gejala/tambah_nilai', $data);
            }
        }
    }

    public function hapus_gejala_nilai($id_nilai)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('nilai_model');
            $hapus = $this->nilai_model->hapus_gejala_nilai($id_nilai);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function edit_gejala_nilai($id_nilai = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('nilai_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama_nilai', 'Nama Nilai', 'trim|required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $nama_nilai = $this->input->post('nama_nilai');
                    $dt = array(
                        'nama_nilai' => $nama_nilai,
                    );
                    $update = $this->nilai_model->update_gejala_nilai($id_nilai, $dt);
                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil diubah</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $dt['nilai'] = $this->nilai_model->get_baris($id_nilai)->row();
                $this->load->view('gejala/edit_nilai', $dt);
            }
        }
    }

    public function nilai_kedekatan($id_gejala)
    {
        $this->load->model('gejala_model');
        $this->load->model('nilai_model');

        $data['id_gejala'] = $id_gejala;
        $data['gejala'] = $this->gejala_model->get_baris($id_gejala)->row();
        $data['nilai1'] = $this->nilai_model->get_all($id_gejala)->result();
        $data['nilai2'] = $this->nilai_model->get_all($id_gejala)->result();

        if ($_POST) {
            $i = 0;
            foreach ($data['nilai1'] as $n1) {
                $ii = 0;
                foreach ($data['nilai2'] as $n2) {
                    if ($i <= $ii) {
                        $nilai_kedekatan = $this->input->post('nilai_' . $n1->id_nilai . '_' . $n2->id_nilai);

                        $dt = array(
                            'id_gejala' => $id_gejala,
                            'id_nilai_1' => $n1->id_nilai,
                            'id_nilai_2' => $n2->id_nilai,
                            'nilai_kedekatan' => $nilai_kedekatan,
                        );

                        $query = $this->nilai_model->get_nilai_kedekatan($id_gejala, $n1->id_nilai, $n2->id_nilai);
                        if ($query->num_rows() > 0) {
                            $nilai = $query->row();
                            $this->nilai_model->update_kedekatan($nilai->id_kedekatan, $dt);
                        } else {
                            $this->nilai_model->tambah_kedekatan($dt);
                        }

                        if ($i <> $ii) {
                            $dt2 = array(
                                'id_gejala' => $id_gejala,
                                'id_nilai_1' => $n2->id_nilai,
                                'id_nilai_2' => $n1->id_nilai,
                                'nilai_kedekatan' => $nilai_kedekatan,
                            );

                            $query = $this->nilai_model->get_nilai_kedekatan($id_gejala, $n2->id_nilai, $n1->id_nilai);
                            if ($query->num_rows() > 0) {
                                $nilai = $query->row();
                                $this->nilai_model->update_kedekatan($nilai->id_kedekatan, $dt2);
                            } else {
                                $this->nilai_model->tambah_kedekatan($dt2);
                            }
                        }
                    }
                    $ii++;
                }
                $i++;
            }
            $this->session->set_flashdata('success', '<div class="alert alert-success"><i class="fas fa-check"></i> Nilai Kedekatan berhasil disimpan</div>');
            redirect('admin/gejala/nilai-kedekatan/' . $id_gejala);
        } else {
            $i = 0;
            foreach ($data['nilai1'] as $n1) {
                $ii = 0;
                foreach ($data['nilai2'] as $n2) {
                    if ($i <= $ii) {
                        $nilai = $this->nilai_model->get_nilai_kedekatan($id_gejala, $n1->id_nilai, $n2->id_nilai)->row();
                        $nilai = empty($nilai->nilai_kedekatan) ? '' : floatval($nilai->nilai_kedekatan);
                        $data['nilai'][$i][$ii] = $nilai;
                    }
                    $ii++;
                }
                $i++;
            }
            $this->load->view('gejala/kedekatan', $data);
        }
    }

    public function cek_kode_gejala($kode_gejala)
    {
        $this->load->model('gejala_model');
        $query = $this->gejala_model->cek_kode_gejala($kode_gejala, $this->input->post('kode_gejala_tmp'));
        if ($query->num_rows() > 0) {
            $this->form_validation->set_message('cek_kode_gejala', '{field} sudah digunakan !');
            return FALSE;
        } else {
            return TRUE;
        }
    }
}

/* End of file Gejala.php */
/* Location: ./application/controllers/Gejala.php */
