<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Member extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('member/data');
    }

    public function list_member_json()
    {
        $this->load->model('member_model');

        $requestData = $_REQUEST;
        $fetch = $this->member_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama'];
            $nestedData[] = $row['alamat'];
            $nestedData[] = $row['jenis_kelamin'];
            $nestedData[] = $row['no_hp'];
            $nestedData[] = $row['username'];
            $nestedData[] = "<a href='" . site_url('admin/member/hapus-member/' . $row['id_member']) . "' id='HapusMember' class='text-danger font-weight-bold'>Hapus</a> |
            <a href='" . site_url('admin/member/edit-member/' . $row['id_member']) . "' id='EditMember' class='text-success font-weight-bold'>Ubah</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_member()
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama', 'Nama', 'required', array('required' => "Isi dulu %s",));
                $this->form_validation->set_rules('alamat', 'Alamat', 'required', array('required' => "Isi dulu %s",));
                $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required', array('required' => "Isi dulu %s",));
                $this->form_validation->set_rules('no_hp', 'No HP', 'required|numeric', array('required' => "Isi dulu %s", 'numeric' => "%s harus angka",));
                $this->form_validation->set_rules('username', 'Username', 'required|is_unique[pengguna.username]', array('required' => "Isi dulu %s", 'is_unique' => "%s sudah digunakan",));
                $this->form_validation->set_rules('password', 'Password', 'required', array('required' => "Isi dulu %s",));
                $this->form_validation->set_rules('confirm_password', 'Ulangi Password', 'required|matches[password]', array('required' => "Isi dulu %s", 'matches' => "%s tidak sama",));

                if ($this->form_validation->run()) {

                    $this->load->model('pengguna_model');
                    $this->load->model('member_model');

                    $params = array(
                        'nama_lengkap' => $this->input->post('nama', TRUE),
                        'username' => $this->input->post('username', TRUE),
                        'password' => password_hash($this->input->post('confirm_password', TRUE), PASSWORD_DEFAULT),
                        'akses_level' => 'Member',
                    );
                    $id_pengguna = $this->pengguna_model->add_pengguna($params);

                    $params2 = array(
                        'nama' => $this->input->post('nama', TRUE),
                        'alamat' => $this->input->post('alamat', TRUE),
                        'jenis_kelamin' => $this->input->post('jenis_kelamin', TRUE),
                        'no_hp' => $this->input->post('no_hp', TRUE),
                        'id_pengguna' => $id_pengguna,
                    );
                    $insert = $this->member_model->tambah_member($params2);

                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->view('member/tambah');
            }
        }
    }

    public function hapus_member($id_member)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('member_model');
            $member = $this->member_model->get_baris($id_member)->row_array();
            $this->load->model('pengguna_model');
            $hapus = $this->pengguna_model->hapus_pengguna($member['id_pengguna']);
            $this->member_model->hapus_member($id_member);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function edit_member($id_member = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('member_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama', 'Nama', 'required', array('required' => "Isi dulu %s",));
                $this->form_validation->set_rules('alamat', 'Alamat', 'required', array('required' => "Isi dulu %s",));
                $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required', array('required' => "Isi dulu %s",));
                $this->form_validation->set_rules('no_hp', 'No HP', 'required|numeric', array('required' => "Isi dulu %s", 'numeric' => "%s harus angka",));

                if ($this->form_validation->run()) {
                    $params2 = array(
                        'nama' => $this->input->post('nama', TRUE),
                        'alamat' => $this->input->post('alamat', TRUE),
                        'jenis_kelamin' => $this->input->post('jenis_kelamin', TRUE),
                        'no_hp' => $this->input->post('no_hp', TRUE),
                    );
                    $update = $this->member_model->update_member($id_member, $params2);
                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil diubah</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $dt['member'] = $this->member_model->get_baris($id_member)->row();
                $this->load->view('member/edit', $dt);
            }
        }
    }
}


/* End of file Member.php */
/* Location: ./application/controllers/Member.php */
