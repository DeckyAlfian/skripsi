<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Password extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    public function index()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('password_lama', 'Password Lama', 'trim|required|callback_cek_password_lama');
        $this->form_validation->set_rules('password_baru', 'Password Baru', 'trim|required');
        $this->form_validation->set_rules('ulangi_password', 'Ulangi Password Baru', 'trim|required|matches[password_baru]');

        $this->form_validation->set_message('required', '%s harus diisi !');
        $this->form_validation->set_message('matches', '%s tidak sama !');

        if ($this->form_validation->run()) {
            $this->load->model('pengguna_model');
            $params = array(
                'password' => password_hash($this->input->post('ulangi_password', TRUE), PASSWORD_DEFAULT),
            );
            $this->pengguna_model->update_pengguna($this->session->userdata('id_pengguna'), $params);
            $this->session->set_flashdata('success', '<div class="alert alert-success" role="alert">Password berhasil diubah</div>');
            redirect('admin/password');
        } else {
            $this->load->view('password_admin');
        }
    }

    public function cek_password_lama($password)
    {
        $this->load->model('pengguna_model');
        if ($password != '') {
            $pengguna = $this->pengguna_model->get_pengguna($this->session->userdata('id_pengguna'))->row_array();
            if (password_verify($password, $pengguna['password'])) {
                return TRUE;
            } else {
                $this->form_validation->set_message('cek_password_lama', '{field} salah');
                return FALSE;
            }
        }
    }
}


/* End of file Password.php */
/* Location: ./application/controllers/Password.php */