<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Home extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('template_admin/home');
    }

}


/* End of file Home.php */
/* Location: ./application/controllers/Home.php */