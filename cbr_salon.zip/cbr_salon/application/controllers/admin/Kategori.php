<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('kategori/data');
    }

    public function list_kategori_json()
    {
        $this->load->model('kategori_model');

        $requestData = $_REQUEST;
        $fetch = $this->kategori_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama_kategori'];
            $nestedData[] = "<a href='" . site_url('admin/kategori/hapus-kategori/' . $row['id_kategori']) . "' id='HapusKategori' class='text-danger font-weight-bold'>Hapus</a> |
            <a href='" . site_url('admin/kategori/edit-kategori/' . $row['id_kategori']) . "' id='EditKategori' class='text-success font-weight-bold'>Ubah</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_kategori()
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama_kategori', 'Nama Kategori', 'required', array('required' => "Isi dulu %s",));

                if ($this->form_validation->run()) {

                    $this->load->model('kategori_model');

                    $params = array(
                        'nama_kategori' => $this->input->post('nama_kategori', TRUE),
                    );
                    $insert = $this->kategori_model->tambah_kategori($params);

                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->view('kategori/tambah');
            }
        }
    }

    public function hapus_kategori($id_kategori)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('kategori_model');
            $hapus = $this->kategori_model->hapus_kategori($id_kategori);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function edit_kategori($id_kategori = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('kategori_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama_kategori', 'Nama Kategori', 'required', array('required' => "Isi dulu %s",));

                if ($this->form_validation->run()) {
                    $params2 = array(
                        'nama_kategori' => $this->input->post('nama_kategori', TRUE),
                    );
                    $update = $this->kategori_model->update_kategori($id_kategori, $params2);
                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil diubah</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $dt['kategori'] = $this->kategori_model->get_baris($id_kategori)->row();
                $this->load->view('kategori/edit', $dt);
            }
        }
    }
}


/* End of file Kategori.php */
/* Location: ./application/controllers/Kategori.php */
