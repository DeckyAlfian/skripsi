<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Solusi extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('solusi/data');
    }

    public function list_solusi_json()
    {
        $this->load->model('solusi_model');

        $requestData = $_REQUEST;
        $fetch = $this->solusi_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama_penyakit'];
            $nestedData[] = $row['solusi_penyakit'];
            $nestedData[] = "<a href='" . site_url('admin/solusi/hapus-solusi/' . $row['id_solusi']) . "' id='HapusSolusi' class='text-danger font-weight-bold'>Hapus</a> |
            <a href='" . site_url('admin/solusi/edit-solusi/' . $row['id_solusi']) . "' id='EditSolusi' class='text-success font-weight-bold'>Ubah</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_solusi()
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('id_penyakit', 'Nama Penyakit', 'required|is_unique[solusi.id_penyakit]');
                $this->form_validation->set_rules('solusi_penyakit', 'Solusi', 'trim|required');

                $this->form_validation->set_message('required', '%s harus diisi !');
                $this->form_validation->set_message('is_unique', '%s sudah ada !');

                if ($this->form_validation->run()) {
                    $this->load->model('solusi_model');
                    $solusi_penyakit = $this->input->post('solusi_penyakit');
                    $id_penyakit = $this->input->post('id_penyakit');
                    $dt = array(
                        'solusi_penyakit' => $solusi_penyakit,
                        'id_penyakit' => $id_penyakit,
                    );
                    $insert = $this->solusi_model->tambah_solusi($dt);
                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->model('penyakit_model');
                $data['penyakit'] = $this->penyakit_model->get_all()->result();
                $this->load->view('solusi/tambah', $data);
            }
        }
    }

    public function hapus_solusi($id_solusi)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('solusi_model');
            $hapus = $this->solusi_model->hapus_solusi($id_solusi);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function edit_solusi($id_solusi = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('solusi_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('id_penyakit', 'Nama Penyakit', 'required|callback_cek_id_penyakit');
                $this->form_validation->set_rules('solusi_penyakit', 'Solusi', 'trim|required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $solusi_penyakit = $this->input->post('solusi_penyakit');
                    $id_penyakit = $this->input->post('id_penyakit');
                    $dt = array(
                        'solusi_penyakit' => $solusi_penyakit,
                        'id_penyakit' => $id_penyakit,
                    );
                    $update = $this->solusi_model->update_solusi($id_solusi, $dt);
                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil diubah</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->model('penyakit_model');
                $data['penyakit'] = $this->penyakit_model->get_all()->result();
                $data['solusi'] = $this->solusi_model->get_baris($id_solusi)->row();
                $this->load->view('solusi/edit', $data);
            }
        }
    }

    public function cek_id_penyakit($id_penyakit)
    {
        $this->load->model('solusi_model');
        $query = $this->solusi_model->cek_id_penyakit($id_penyakit, $this->input->post('id_penyakit_tmp'));
        if ($query->num_rows() > 0) {
            $this->form_validation->set_message('cek_id_penyakit', '{field} sudah ada !');
            return FALSE;
        } else {
            return TRUE;
        }
    }
}

/* End of file Solusi.php */
/* Location: ./application/controllers/Solusi.php */
