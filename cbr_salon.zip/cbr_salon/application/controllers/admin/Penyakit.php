<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penyakit extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('penyakit/data');
    }

    public function list_penyakit_json()
    {
        $this->load->model('penyakit_model');

        $requestData = $_REQUEST;
        $fetch = $this->penyakit_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['kode_penyakit'];
            $nestedData[] = $row['nama_penyakit'];
            $nestedData[] = "<a href='" . site_url('admin/penyakit/hapus-penyakit/' . $row['id_penyakit']) . "' id='HapusPenyakit' class='text-danger font-weight-bold'>Hapus</a> |
            <a href='" . site_url('admin/penyakit/edit-penyakit/' . $row['id_penyakit']) . "' id='EditPenyakit' class='text-success font-weight-bold'>Ubah</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_penyakit()
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('kode_penyakit', 'Kode Penyakit', 'trim|required|is_unique[penyakit.kode_penyakit]');
                $this->form_validation->set_rules('nama_penyakit', 'Nama Penyakit', 'trim|required');

                $this->form_validation->set_message('required', '%s harus diisi !');
                $this->form_validation->set_message('is_unique', '%s sudah digunakan !');

                if ($this->form_validation->run()) {
                    $this->load->model('penyakit_model');
                    $kode_penyakit = $this->input->post('kode_penyakit');
                    $nama_penyakit = $this->input->post('nama_penyakit');
                    $dt = array(
                        'kode_penyakit' => $kode_penyakit,
                        'nama_penyakit' => $nama_penyakit,
                    );
                    $insert = $this->penyakit_model->tambah_penyakit($dt);
                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->view('penyakit/tambah');
            }
        }
    }

    public function hapus_penyakit($id_penyakit)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('penyakit_model');
            $hapus = $this->penyakit_model->hapus_penyakit($id_penyakit);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function edit_penyakit($id_penyakit = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('penyakit_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('kode_penyakit', 'Kode Penyakit', 'trim|required|callback_cek_kode_penyakit');
                $this->form_validation->set_rules('nama_penyakit', 'Nama Penyakit', 'trim|required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $kode_penyakit = $this->input->post('kode_penyakit');
                    $nama_penyakit = $this->input->post('nama_penyakit');
                    $dt = array(
                        'kode_penyakit' => $kode_penyakit,
                        'nama_penyakit' => $nama_penyakit,
                    );
                    $update = $this->penyakit_model->update_penyakit($id_penyakit, $dt);
                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil diubah</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $dt['penyakit'] = $this->penyakit_model->get_baris($id_penyakit)->row();
                $this->load->view('penyakit/edit', $dt);
            }
        }
    }

    public function cek_kode_penyakit($kode_penyakit)
    {
        $this->load->model('penyakit_model');
        $query = $this->penyakit_model->cek_kode_penyakit($kode_penyakit, $this->input->post('kode_penyakit_tmp'));
        if ($query->num_rows() > 0) {
            $this->form_validation->set_message('cek_kode_penyakit', '{field} sudah digunakan !');
            return FALSE;
        } else {
            return TRUE;
        }
    }
}

/* End of file Penyakit.php */
/* Location: ./application/controllers/Penyakit.php */
