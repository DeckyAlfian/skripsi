<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kasus extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        if ($this->session->userdata('level') != "Admin") {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->model('gejala_model');
        $q_gejala = $this->gejala_model->get_all();
        $data['gejala'] = $q_gejala->result();
        $this->load->view('kasus/data', $data);
    }

    public function list_kasus_json()
    {
        $this->load->model('kasus_model');
        $this->load->model('gejala_model');
        $q_gejala = $this->gejala_model->get_all();

        $requestData = $_REQUEST;
        $fetch = $this->kasus_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama_kasus'];
            foreach ($q_gejala->result_array() as $gejala) {
                $klt = $this->kasus_model->get_kasus_gejala($row['id_kasus'], $gejala['id_gejala'])->row_array();
                $nilai = empty($klt['nama_nilai']) ? '' : $klt['nama_nilai'];
                $nestedData[] = $nilai;
            }
            $nestedData[] = $row['nama_penyakit'];
            $nestedData[] = "<a href='" . site_url('admin/kasus/hapus-kasus/' . $row['id_kasus']) . "' id='HapusKasus' class='text-danger font-weight-bold'>Hapus</a> |
            <a href='" . site_url('admin/kasus/edit-kasus/' . $row['id_kasus']) . "' id='EditKasus' class='text-success font-weight-bold'>Ubah</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_kasus()
    {
        if ($this->input->is_ajax_request()) {

            $this->load->model('penyakit_model');
            $this->load->model('gejala_model');
            $this->load->model('nilai_model');
            $data['penyakit'] = $this->penyakit_model->get_all()->result();
            $data['gejala'] = $this->gejala_model->get_all()->result();
            foreach ($data['gejala'] as $gejala) {
                $data['nilai'][$gejala->id_gejala] = $this->nilai_model->get_all($gejala->id_gejala)->result();
            }

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama_kasus', 'Nama Kasus', 'trim|required');
                foreach ($data['gejala'] as $gejala) {
                    $this->form_validation->set_rules('id_gejala_' . $gejala->id_gejala, $gejala->nama_gejala, 'required');
                }
                $this->form_validation->set_rules('id_penyakit', 'Penyakit', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $this->load->model('kasus_model');

                    $nama_kasus = $this->input->post('nama_kasus');
                    $id_penyakit = $this->input->post('id_penyakit');
                    $dt = array(
                        'nama_kasus' => $nama_kasus,
                        'id_penyakit' => $id_penyakit,
                    );
                    $insert = $this->kasus_model->tambah_kasus($dt);
                    $id_kasus = $insert['id'];

                    foreach ($data['gejala'] as $gejala) {
                        $id_nilai = $this->input->post('id_gejala_' . $gejala->id_gejala);
                        $dt = array(
                            'id_kasus' => $id_kasus,
                            'id_gejala' => $gejala->id_gejala,
                            'id_nilai' => $id_nilai,
                        );
                        $this->kasus_model->tambah_kasus_gejala($dt);
                    }

                    if ($insert['result']) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil ditambahkan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->view('kasus/tambah', $data);
            }
        }
    }

    public function hapus_kasus($id_kasus)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('kasus_model');
            $hapus = $this->kasus_model->hapus_kasus($id_kasus);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function edit_kasus($id_kasus = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('kasus_model');
            $this->load->model('penyakit_model');
            $this->load->model('gejala_model');
            $this->load->model('nilai_model');
            $data['kasus'] = $this->kasus_model->get_baris($id_kasus)->row();
            $data['penyakit'] = $this->penyakit_model->get_all()->result();
            $data['gejala'] = $this->gejala_model->get_all()->result();
            foreach ($data['gejala'] as $gejala) {
                $data['nilai'][$gejala->id_gejala] = $this->nilai_model->get_all($gejala->id_gejala)->result();
                $res = $this->kasus_model->get_kasus_gejala($id_kasus, $gejala->id_gejala)->row_array();
                $nilai = empty($res['id_nilai']) ? '' : $res['id_nilai'];
                $data['alt'][$gejala->id_gejala] = $nilai;
            }

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nama_kasus', 'Nama Kasus', 'trim|required');
                foreach ($data['gejala'] as $gejala) {
                    $this->form_validation->set_rules('id_gejala_' . $gejala->id_gejala, $gejala->nama_gejala, 'required');
                }
                $this->form_validation->set_rules('id_penyakit', 'Penyakit', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $nama_kasus = $this->input->post('nama_kasus');
                    $id_penyakit = $this->input->post('id_penyakit');
                    $dt = array(
                        'nama_kasus' => $nama_kasus,
                        'id_penyakit' => $id_penyakit,
                    );
                    $update = $this->kasus_model->update_kasus($id_kasus, $dt);

                    foreach ($data['gejala'] as $gejala) {
                        $id_nilai = $this->input->post('id_gejala_' . $gejala->id_gejala);
                        $dt2 = array(
                            'id_kasus' => $id_kasus,
                            'id_gejala' => $gejala->id_gejala,
                            'id_nilai' => $id_nilai,
                        );
                        $res = $this->kasus_model->get_kasus_gejala($id_kasus, $gejala->id_gejala);
                        if ($res->num_rows() > 0) {
                            $klt = $res->row();
                            $this->kasus_model->update_kasus_gejala($klt->id_kasus_gejala, $dt2);
                        } else {
                            $this->kasus_model->tambah_kasus_gejala($dt2);
                        }
                    }

                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil diubah</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->view('kasus/edit', $data);
            }
        }
    }
}


/* End of file Kasus.php */
/* Location: ./application/controllers/Kasus.php */
