<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Chat extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('home');
        }
    }

    public function index()
    {
        $this->load->view('chat/data');
    }

    public function list_chat_json()
    {
        $this->load->model('chat_model');

        $requestData = $_REQUEST;

        if ($this->session->userdata('level') == 'Member'){
            $this->load->model('member_model');
            $member = $this->member_model->get_baris_by_id_pengguna($this->session->userdata('id_pengguna'))->row_array();
            $id_member = $member['id_member'];
            $fetch = $this->chat_model->fetch_data_member($id_member, $requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);
        }else{
            $fetch = $this->chat_model->fetch_data($requestData['order'][0]['column'], $requestData['order'][0]['dir'], $requestData['start'], $requestData['length']);
        }

        $totalData = $fetch['totalData'];
        $totalFiltered = $fetch['totalFiltered'];
        $query = $fetch['query'];

        $data = array();
        foreach ($query->result_array() as $row) {
            $nestedData = array();
            $nestedData[] = $row['nomor'];
            $nestedData[] = $row['nama'];
            $nestedData[] = $row['tanggal'];
            $nestedData[] = $row['judul'];
            $nestedData[] = $row['terakhir_dibalas'];
            $nestedData[] = "<a href='" . site_url('chat/hapus-chat/' . $row['id_chat']) . "' id='HapusChat' class='text-danger font-weight-bold'>Hapus</a>
                | <a href='" . site_url('chat/balas-chat/' . $row['id_chat']) . "' id='BalasChat' class='text-success font-weight-bold'>Balas</a>";
            $data[] = $nestedData;
        }

        $json_data = array(
            "draw" => intval($requestData['draw']),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function tambah_chat()
    {
        if ($this->input->is_ajax_request()) {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('judul', 'Judul Konsultasi', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $this->load->model('chat_model');
                    $this->load->model('member_model');
                    $member = $this->member_model->get_baris_by_id_pengguna($this->session->userdata('id_pengguna'))->row_array();
                    $id_member = $member['id_member'];
                    $tanggal = date('Y-m-d');
                    $judul = $this->input->post('judul');
                    $terakhir_dibalas = 'Member';
                    $dt = array(
                        'id_member' => $id_member,
                        'tanggal' => $tanggal,
                        'judul' => $judul,
                        'terakhir_dibalas' => $terakhir_dibalas,
                    );
                    $insert = $this->chat_model->tambah_chat($dt);
                    if ($insert) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil disimpan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $this->load->view('chat/tambah');
            }
        }
    }

    public function hapus_chat($id_chat)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('chat_model');
            $hapus = $this->chat_model->hapus_chat($id_chat);
            if ($hapus) {
                echo json_encode(array(
                    "pesan" => "<font color='green'><i class='fas fa-check'></i> Data berhasil dihapus</font>"
                ));
            } else {
                echo json_encode(array(
                    "pesan" => "<font color='red'><i class='fas fa-warning'></i> Terjadi kesalahan, coba lagi</font>"
                ));
            }
        }
    }

    public function balas_chat($id_chat = NULL)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('chat_model');

            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('pesan', 'Balas Pesan', 'required');

                $this->form_validation->set_message('required', '%s harus diisi !');

                if ($this->form_validation->run()) {
                    $waktu = date('Y-m-d H:i:s');
                    $pesan = $this->input->post('pesan');
                    $oleh = $this->session->userdata('level');
                    $dt = array(
                        'id_chat' => $id_chat,
                        'waktu' => $waktu,
                        'pesan' => $pesan,
                        'oleh' => $oleh,
                    );
                    $update = $this->chat_model->tambah_chat_detail($dt);

                    $dt2 = array(
                        'terakhir_dibalas' => $oleh,
                    );
                    $this->chat_model->update_chat($id_chat, $dt2);

                    if ($update) {
                        echo json_encode(array(
                            'status' => 1,
                            'pesan' => "<div class='alert alert-success'><i class='fas fa-check'></i> Data berhasil disimpan</div>"
                        ));
                    } else {
                        $this->query_error();
                    }
                } else {
                    $this->input_error();
                }
            } else {
                $data['chat'] = $this->chat_model->get_baris($id_chat)->row();
                $data['chat_detail'] = $this->chat_model->get_chat_detail($id_chat)->result();
                $this->load->view('chat/balas', $data);
            }
        }
    }
}

/* End of file Chat.php */
/* Location: ./application/controllers/Chat.php */
